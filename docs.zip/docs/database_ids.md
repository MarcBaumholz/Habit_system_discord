# Database IDs - Extracted from URLs

## Your Notion Databases:

1. **Users Database**: `278d42a1faf580cea57ff646855a4130`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf580cea57ff646855a4130

2. **Habits Database**: `278d42a1faf581929c22e764556d7dd5`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf581929c22e764556d7dd5

3. **Proofs Database**: `278d42a1faf5810a9564c919c212a9e9`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf5810a9564c919c212a9e9

4. **Learnings Database**: `278d42a1faf5812ea4d6d6010bb32e05`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf5812ea4d6d6010bb32e05

5. **Weeks Database**: `278d42a1faf58105a480e66aeb852e91`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf58105a480e66aeb852e91

6. **Groups Database**: `278d42a1faf581088b3bfa73450f34b4`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf581088b3bfa73450f34b4

7. **Hurdles Database**: `278d42a1faf581ef9ec6d14f07c816e2`
   - URL: https://www.notion.so/marcbaumholz/278d42a1faf581ef9ec6d14f07c816e2

## Integration Token:
- **Token**: `[REDACTED - Use .env file]`

## Status: ✅ Ready to Test!
All databases are created and connected. The bot should now work with your Notion workspace.