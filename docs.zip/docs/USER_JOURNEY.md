# Discord Habit System - Complete User Journey Documentation

## Overview

This document provides step-by-step user journeys for all features in the Discord Habit System. Each journey includes user actions, system responses, and behind-the-scenes processing.

---

## Table of Contents

1. [New User Onboarding](#1-new-user-onboarding)
2. [Creating Your First Keystone Habit](#2-creating-your-first-keystone-habit)
3. [Daily Proof Submission (Manual)](#3-daily-proof-submission-manual)
4. [Daily Proof Submission (Automatic)](#4-daily-proof-submission-automatic)
5. [Weekly Progress Review](#5-weekly-progress-review)
6. [Personality Profile Creation](#6-personality-profile-creation)
7. [Using AI Agents for Coaching](#7-using-ai-agents-for-coaching)
8. [Sharing Learnings & Hurdles](#8-sharing-learnings--hurdles)
9. [Weekly Challenges](#9-weekly-challenges)
10. [Buddy System](#10-buddy-system)
11. [Batch Participation](#11-batch-participation)
12. [Pausing & Reactivating](#12-pausing--reactivating)
13. [Using Habit Tools](#13-using-habit-tools)
14. [Personal Assistant Interactions](#14-personal-assistant-interactions)
15. [Admin: Creating a Batch](#15-admin-creating-a-batch)

---

## 1. New User Onboarding

### User Goal
Join the Discord Habit System and get set up for the 66-day challenge.

### Step-by-Step Journey

#### Step 1: Join Command
**User Action:**
```
/join
```

**System Processing:**
1. Checks if user exists in Notion Users database
2. If new:
   - Creates user record with Discord ID, name
   - Sets status to "active"
   - Checks if current batch exists (pre-phase or active)
   - Enrolls user in current batch if available

**User Sees:**
```
✅ Welcome to the 66-Day Habit Challenge!

Your personal channel has been created: #personal-username

Next steps:
1. Check #personal-username for your welcome message
2. Complete the personality questionnaire
3. Create your first keystone habit

Current Batch: January 2026
Status: Pre-Phase (starts in 5 days)
```

#### Step 2: Personal Channel Created
**System Processing:**
1. Creates private Discord channel: `#personal-username`
2. Sets permissions (user + bot only)
3. Stores channel ID in Notion
4. Sends welcome message to personal channel

**User Sees (in personal channel):**
```
👋 Welcome, Marc!

This is your private space for habit tracking and personal coaching.

What you can do here:
• Create keystone habits (type "keystone habit")
• Chat with your Personal AI Assistant
• Receive weekly evaluations and feedback
• Ask questions and get personalized support

To get started, complete your personality profile by clicking below:

[Complete Profile Questionnaire]
```

#### Step 3: Initial Exploration
**What happens next:**
- User is now enrolled in system
- If batch exists, they're part of it
- If batch starts soon, they'll receive batch activation announcement
- Daily messages will include them (6 AM motivational quotes)
- They can create habits immediately

**Returning Users:**
If user previously existed but was paused:
```
Welcome back, Marc!

Your account has been reactivated.
Status: Active
Batch: January 2026
Personal Channel: #personal-marc

You'll start receiving weekly analyses again.
```

---

## 2. Creating Your First Keystone Habit

### User Goal
Create a well-defined keystone habit for the 66-day challenge.

### Step-by-Step Journey

#### Step 1: Trigger Habit Flow
**User Action (in personal channel):**
```
keystone habit
```
or
```
create keystone habit
```
or
```
i want to create a new keystone habit
```

**System Response:**
```
🔥 Let's create your keystone habit!

A keystone habit is a transformative habit that creates a ripple effect across your life.

Click the button below to start the guided creation process.

[🔥 Create Keystone Habit]
```

#### Step 2: Modal 1 - Basic Information
**User Clicks:** "Create Keystone Habit" button

**Modal Opens:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         Keystone Habit Creation
              Step 1/4: Basics
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Habit Name *
[Morning Meditation                    ]
Max 100 characters

Life Domains *
[Health, Mental Clarity                ]
Comma-separated (e.g., Health, Career)

Context: When and Where? *
[Right after waking up, in my bedroom
 before checking phone                 ]
Max 1000 characters

Difficulty Level *
[ ] Easy  [•] Medium  [ ] Hard

                           [Submit]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**User Fills:**
- Name: "Morning Meditation"
- Domains: "Health, Mental Clarity"
- Context: "Right after waking up, in my bedroom before checking phone"
- Difficulty: Medium

**User Submits**

#### Step 3: Day Selector
**System Shows:**
```
📅 When will you practice this habit?

Select the days you want to commit to:

[⭕ Mon]  [⭕ Tue]  [⭕ Wed]  [⭕ Thu]  [⭕ Fri]  [⭕ Sat]  [⭕ Sun]

Selected days: 0

                    [Continue ⏭️] (disabled)
```

**User Clicks:** Mon, Tue, Wed, Thu, Fri (Monday-Friday)

**System Updates:**
```
📅 When will you practice this habit?

Select the days you want to commit to:

[✅ Mon]  [✅ Tue]  [✅ Wed]  [✅ Thu]  [✅ Fri]  [⭕ Sat]  [⭕ Sun]

Selected days: 5

                    [Continue ⏭️] (enabled)
```

**User Clicks:** Continue

**System Shows:**
```
Great! You'll practice this habit 5 times per week.

Ready for the next step?

[Continue to Step 2/4 ➡️]
```

#### Step 4: Modal 2 - Goals & Motivation
**User Clicks:** "Continue to Step 2/4"

**Modal Opens:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         Keystone Habit Creation
      Step 2/4: Goals & Motivation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SMART Goal *
[Meditate for 10 minutes every weekday
 morning for the next 66 days to build
 mental clarity and reduce stress      ]

Epic Meaning (Your "Big Why") *
[I want to become someone who starts
 the day with intention rather than
 reactivity. Meditation aligns with...  ]

Minimal Dose (0.8 Rule) *
[2 minutes of breathing                ]

Habit Loop *
Cue: [Alarm at 6:30 AM                 ]
Routine: [10 min meditation            ]
Reward: [Coffee + journaling           ]

Consequences of Not Committing *
[I'll continue feeling scattered and
 reactive, starting days with stress...  ]

                           [Submit]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**User Fills All Fields** and **Submits**

**System Shows:**
```
Excellent progress! Let's dive deeper.

[Continue to Step 3/4 ➡️]
```

#### Step 5: Modal 3 - Reflection & Planning
**User Clicks:** "Continue to Step 3/4"

**Modal Opens:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         Keystone Habit Creation
    Step 3/4: Reflection & Planning
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Curiosity, Passion & Purpose *
[I'm curious about how meditation will
 change my mental state over 66 days.
 I'm passionate about self-improvement...]

Autonomy: How does this give you control? *
[By starting my day intentionally, I
 take control of my mental state rather
 than letting external factors dictate...]

Anticipated Hurdles *
[1. Forgetting when I wake up late
 2. Feeling too tired
 3. Getting distracted by phone          ]

Reminder Type *
[Phone alarm + accountability buddy check]

                           [Submit]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**User Fills All Fields** and **Submits**

#### Step 6: Summary Review
**System Shows:**
```
📋 Habit Summary

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BASIC INFORMATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Name: Morning Meditation
Domains: Health, Mental Clarity
Frequency: 5 times per week (Mon-Fri)
Difficulty: Medium
Context: Right after waking up, in my bedroom...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GOALS & MOTIVATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SMART Goal: Meditate for 10 minutes every...
Why: I want to become someone who starts...
Minimal Dose: 2 minutes of breathing

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IMPLEMENTATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Habit Loop:
  • Cue: Alarm at 6:30 AM
  • Routine: 10 min meditation
  • Reward: Coffee + journaling

Hurdles: 1. Forgetting when I wake up late...
Reminder: Phone alarm + accountability buddy

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Ready to commit?

[Step 4/4: Sign 66-Day Commitment]
```

#### Step 7: Modal 4 - 66-Day Commitment
**User Clicks:** "Sign 66-Day Commitment"

**Modal Opens:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         Keystone Habit Creation
        Step 4/4: 66-Day Contract
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

I commit to practicing this habit for
the next 66 days to make it automatic.

Type "I commit" below to sign:

[                                      ]

                           [Submit]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**User Types:**
```
I commit
```

**User Submits**

#### Step 8: Success & Celebration
**System Processing:**
1. Validates commitment signature
2. Creates habit in Notion Habits database
3. Assigns current batch name
4. Calculates frequency from selected days (5)
5. Clears cached modal data
6. Regenerates AI profile for Personal Assistant

**User Sees:**
```
🎉 Keystone Habit Created Successfully!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
           Morning Meditation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Frequency: 5 times per week (Mon-Fri)
✅ Minimal Dose: 2 minutes of breathing
✅ Batch: January 2026
✅ 66-day journey starts on Day 1

Your habit is now active! Start submitting
proofs daily with /proof or by posting in
#accountability-group

Next steps:
1. Submit your first proof today
2. Check your weekly summary with /summary
3. Get coaching with /mentor

[Random celebration GIF]
```

**System Adds:** 🎊 reaction to the original "keystone habit" message

---

## 3. Daily Proof Submission (Manual)

### User Goal
Log a habit completion manually using the /proof command.

### Step-by-Step Journey

#### Step 1: Execute /proof Command
**User Action:**
```
/proof unit:10 minutes note:Felt great today! minimal_dose:false cheat_day:false
```

**System Processing:**
1. Validates user exists in system
2. Gets user's habits (filtered by current batch)
3. If user has only 1 habit, auto-selects it
4. If multiple habits, shows selection dropdown (not shown in this example)

#### Step 2: Proof Validation
**System Processing:**
1. Parses unit: "10 minutes"
2. Compares to minimal dose: "2 minutes"
3. Determines: Full proof (not minimal dose)
4. Creates proof record in Notion:
   - User relation
   - Habit relation
   - Date: Today
   - Unit: "10 minutes"
   - Note: "Felt great today!"
   - Is Minimal Dose: false
   - Is Cheat Day: false
   - Batch: "january 2026"

#### Step 3: Success Confirmation
**User Sees:**
```
✅ Proof logged successfully!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         Morning Meditation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 Date: 2025-01-15
⏱️ Unit: 10 minutes
📝 Note: Felt great today!

This week: 3/5 proofs completed (60%)

Keep it up! 🔥
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

#### Additional Proof Examples

**Minimal Dose Proof:**
```
/proof unit:2 minutes minimal_dose:true note:Busy morning
```
**Result:**
```
⭐ Minimal dose proof logged!

Morning Meditation
📅 2025-01-15
⏱️ 2 minutes (Minimal dose - 0.8 rule)

This week: 4/5 proofs completed (80%)

Even small steps count! 💪
```

**Cheat Day:**
```
/proof unit:0 minutes cheat_day:true note:Rest day
```
**Result:**
```
🎯 Cheat day logged!

Morning Meditation
📅 2025-01-15
🛌 Planned rest day

This week: 4/5 proofs + 1 cheat day

Recovery is part of the process! 🧘
```

**With Attachment:**
```
/proof unit:10 minutes attachment:[photo of meditation setup]
```
**Result:**
```
✅ Proof logged with photo!

Morning Meditation
📅 2025-01-15
⏱️ 10 minutes
📷 Photo attached

This week: 5/5 proofs completed (100%)

Perfect week! 🌟
```

---

## 4. Daily Proof Submission (Automatic)

### User Goal
Log a habit completion by simply posting a message in the accountability channel.

### Step-by-Step Journey

#### Step 1: Post Natural Message
**User Action (in #accountability-group):**
```
Did 15min meditation this morning, feeling focused!
```

**System Processing (runs in background):**
1. **Webhook Detection:** Bot checks if message is from webhook first
2. **Message Analysis:**
   - Gets user by Discord ID
   - Gets user's habits (filtered by current batch)
   - Sends message + habits to AI Message Analyzer

3. **AI Classification (Perplexity Sonar):**
   - Analyzes: "Did 15min meditation this morning, feeling focused!"
   - Identifies: Habit name ("meditation")
   - Extracts: Unit ("15 minutes")
   - Extracts: Note ("feeling focused")
   - Classification: "proof"

4. **Semantic Matching:**
   - Matches "meditation" to habit "Morning Meditation"
   - Scoring:
     - Partial name match: +50 points
     - Synonym match: +30 points (meditation → mindfulness)
     - Context match: +15 points ("morning")
     - Total: 95 points → High confidence

5. **Proof Creation:**
   - Creates proof in Notion Proofs database
   - Compares "15 minutes" to minimal dose "2 minutes"
   - Result: Full proof (not minimal dose)

#### Step 2: Bot Confirmation
**User Sees (bot reacts to message):**
```
✅ [Checkmark reaction added to message]
```

**User Sees (bot reply):**
```
Morning Meditation proof logged! (4/5 this week)
```

**If note is substantial (>10 characters), also posts to #learnings-feed:**
```
💡 Marc shared a learning:
"feeling focused"

From habit: Morning Meditation
```

#### Alternative Automatic Detection Examples

**Different Wording:**
```
User: "30min deep work session done"
Bot: ✅ Deep Work proof logged! (2/7 this week)
```

**With Minimal Dose:**
```
User: "Only had time for 2min breathing today"
Bot: ⭐ Morning Meditation proof logged (minimal dose)! (5/5 this week)
```

**Ambiguous Message:**
```
User: "Did my thing this morning"
Bot: ⚠️ Could you clarify which habit you completed?
      1. Morning Meditation
      2. Deep Work
      3. Exercise
```

**Multiple Habits in One Message:**
```
User: "10min meditation + 30min workout"
Bot: ✅ Morning Meditation proof logged! (3/5)
     ✅ Exercise proof logged! (4/7)
```

---

## 5. Weekly Progress Review

### User Goal
Check weekly habit progress and statistics.

### Step-by-Step Journey

#### Step 1: Request Summary
**User Action:**
```
/summary
```
(No week parameter = current week)

**System Processing:**
1. Gets user from Notion
2. Calculates current week (Monday-Sunday)
3. Gets all user habits (filtered by current batch)
4. Gets all proofs for current week
5. Gets all historical proofs (for streak calculation)
6. Calculates:
   - Total proofs this week
   - Minimal dose count
   - Cheat day count
   - Completion rate per habit
   - Current streak
   - Best streak
   - Last proof date per habit

#### Step 2: Formatted Summary
**User Sees:**
```
📊 Weekly Habit Summary
Week: 2025-01-13 to 2025-01-19

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OVERVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total Proofs: 12
  • Full proofs: 10
  • Minimal dose: 2
  • Cheat days: 0
Overall Completion: 85.7% 📈

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STREAK STATUS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Current Streak: 14 days 🔥
Best Streak: 21 days
Total Habits: 3

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HABIT BREAKDOWN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Morning Meditation
   Progress: 5/5 (100%) ✅
   Last proof: Today

2. Deep Work
   Progress: 5/7 (71%) ⚠️
   Last proof: Yesterday

3. Exercise
   Progress: 2/5 (40%) 🚨
   Last proof: 3 days ago

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💬 Great work on Morning Meditation!
   Focus on Exercise this week.

Use /summary week:1 to see Week 1
```

#### Viewing Specific Week
**User Action:**
```
/summary week:2
```

**User Sees:**
```
📊 Weekly Habit Summary
Week 2: 2025-01-06 to 2025-01-12

[Same format as above, but for Week 2 data]
```

#### Performance-Based Messages

**100%+ Completion:**
```
🌟 INCREDIBLE! You hit 100% this week!
   You're building unstoppable momentum!
```

**75-99% Completion:**
```
💪 Strong week! You're in the flow zone.
   Keep this consistency going!
```

**50-74% Completion:**
```
👍 Good progress, but room to improve.
   Which habit needs more focus?
```

**<50% Completion:**
```
⚠️ Challenging week. Let's regroup.
   Would smaller goals help? Try /mentor
```

**0% Completion:**
```
🚨 No proofs this week. Are you okay?
   Consider /pause if you need a break.
```

---

## 6. Personality Profile Creation

### User Goal
Complete personality questionnaire to unlock personalized AI coaching.

### Step-by-Step Journey

#### Step 1: Start Onboarding
**User Action:**
```
/onboard
```

**System Checks:**
- User exists in system? → YES
- Profile already exists? → NO
- Proceed to Modal 1

#### Step 2: Modal 1 - Basic Personality
**Modal Opens:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Personality Questionnaire
            Part 1/2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Personality Type (optional)
[INTJ                                  ]
e.g., INTJ, ENFP from 16Personalities

Core Values (3 values) *
[Growth, Authenticity, Health          ]
Comma-separated

Life Vision (5 years) *
[Build a sustainable creative business
 while maintaining physical & mental
 health. Live intentionally...         ]

Main Goals (Next 66 days) *
[1. Establish meditation practice
 2. Complete deep work daily
 3. Build fitness foundation           ]
Line-separated

Big Five Traits (optional)
[High conscientiousness (8/10)
 High openness (9/10)
 Moderate extraversion (5/10)...       ]

                           [Submit]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**User Fills:**
- Personality Type: INTJ
- Core Values: Growth, Authenticity, Health
- Life Vision: [detailed vision]
- Main Goals: [3 goals, line-separated]
- Big Five: [trait descriptions]

**User Submits**

#### Step 3: Transition to Part 2
**System Shows:**
```
Great! Let's continue with Part 2.

[Continue to Part 2/2 ➡️]
```

#### Step 4: Modal 2 - Additional Details
**User Clicks:** "Continue to Part 2/2"

**Modal Opens:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Personality Questionnaire
            Part 2/2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Life Domains *
[ ] Health        [ ] Career
[ ] Relationships [ ] Finance
[ ] Personal Growth [•] Creativity
[ ] Spirituality  [ ] Adventure

Life Phase *
[Career Building                       ]
e.g., Student, Early Career, Established

Desired Identity *
[Someone who lives intentionally and
 makes daily progress toward meaningful
 goals without sacrificing wellbeing   ]

Open Space (Additional Notes)
[I struggle with perfectionism and
 tend to overwork. Want to build
 sustainable habits...                 ]

                           [Submit]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**User Fills:**
- Life Domains: Health, Personal Growth, Creativity
- Life Phase: Career Building
- Desired Identity: [detailed description]
- Open Space: [additional context]

**User Submits**

#### Step 5: Profile Creation Success
**System Processing:**
1. Validates required fields
2. Creates profile in Notion Personality database:
   - Discord ID (as title field)
   - User relation
   - All questionnaire data
   - Join date (today)
3. Regenerates AI profile for Personal Assistant
4. Creates Markdown profile file in `/data/profiles/`

**User Sees:**
```
✅ Personality Profile Created!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
YOUR PROFILE SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Personality Type: INTJ
Core Values: Growth, Authenticity, Health
Life Phase: Career Building
Domains: Health, Personal Growth, Creativity

Your profile has been saved and will be
used to personalize your habit coaching.

Try these AI-powered features:
• /mentor - Get personalized habit coaching
• /identity - Explore habit-personality fit
• Ask questions in this channel!

[Edit Profile]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

#### Step 6: View Profile Later
**User Action:**
```
/profile
```

**User Sees:**
```
👤 Personality Profile: Marc

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BASIC INFORMATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Personality Type: INTJ
Core Values: Growth, Authenticity, Health
Life Phase: Career Building
Life Domains: Health, Personal Growth,
              Creativity

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VISION & GOALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Life Vision: Build a sustainable creative
             business while maintaining...

Main Goals (66 days):
1. Establish meditation practice
2. Complete deep work daily
3. Build fitness foundation

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PERSONALITY TRAITS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Big Five: High conscientiousness (8/10)
          High openness (9/10)...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IDENTITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Desired Identity: Someone who lives
                  intentionally and makes
                  daily progress...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NOTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
I struggle with perfectionism and tend
to overwork. Want to build sustainable...

                    [Edit Profile]
```

#### Step 7: Edit Profile
**User Clicks:** "Edit Profile" button

**Modal Opens (pre-filled with current data):**
```
[Same as Modal 1 but with current values]
```

**User can edit:**
- Personality Type
- Core Values
- Life Vision
- Main Goals
- Big Five Traits

**Note:** To edit Life Domains, Life Phase, Desired Identity, or Open Space, user must re-run `/onboard`

---

## 7. Using AI Agents for Coaching

### User Goal
Get personalized habit coaching from AI agents.

### Journey 1: Mentor Agent

#### Step 1: Request Coaching
**User Action (in personal channel):**
```
/mentor query:Give me a weekly analysis of my habits
```

**Or simpler:**
```
How are my habits going this week?
```
(Personal Assistant auto-routes to appropriate agent)

**System Processing:**
1. Validates user context
2. Routes request to Orchestrator
3. Orchestrator scores agents:
   - MentorAgent: 0.85 (high match for "weekly analysis")
   - AccountabilityAgent: 0.42
   - Others: <0.40
4. Selects MentorAgent as primary
5. Gathers user context:
   - Habits (current batch)
   - Proofs (last 7 days)
   - Proofs (last 4 weeks for trends)
   - Learnings
   - Summary stats
6. Builds structured prompt with 7-step framework
7. Sends to Perplexity Sonar model
8. Receives AI response

#### Step 2: AI Analysis Response
**User Sees:**
```
🎯 Weekly Habit Analysis from Mentor Agent

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 📊 PERFORMANCE ASSESSMENT

Overall: 85% completion rate (12/14 target)
Status: OPTIMAL FLOW ZONE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## ✅ WHAT WORKED

**Morning Meditation (5/5 - 100%)**
• Perfect consistency on weekdays
• Temporal pattern: 100% morning completions
• Current streak: 14 days 🔥

**Deep Work (5/7 - 71%)**
• Solid weekday performance
• Missed: Saturday, Sunday
• Improving trend: +1 session vs last week

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## ⚠️ WHAT DIDN'T WORK

**Exercise (2/5 - 40%)**
• Missed 3 target days
• Last proof: 3 days ago
• Pattern: Struggling on busy work days

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🎯 ADAPTIVE GOALS RECOMMENDATIONS

🚀 **High Performer** (≥100%)
• Morning Meditation: Consider increasing to
  6-7 days/week or extending to 15 minutes

💪 **Struggling** (<80%)
• Exercise: Reduce frequency to 3 days/week
  OR reduce minimal dose to "10-minute walk"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 📈 4-WEEK TREND ANALYSIS

| Habit       | W1  | W2  | W3  | W4  | Trend | Zone    |
|-------------|-----|-----|-----|-----|-------|---------|
| Meditation  | 80% | 100%| 100%| 100%| ↑     | Optimal |
| Deep Work   | 57% | 71% | 71% | 71% | →     | Optimal |
| Exercise    | 60% | 40% | 60% | 40% | ↓     | Too Hard|

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🔮 NEXT STEPS

1. **Maintain** Morning Meditation momentum
2. **Adjust** Exercise to 3x/week for sustainability
3. **Protect** Deep Work weekday slots
4. **Stack** Exercise with existing routine
   (e.g., after morning meditation)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💬 Reply with specific questions about any
   habit for deeper coaching.

Confidence: 0.87
```

### Journey 2: Identity Agent

#### Step 1: Request Personality-Habit Analysis
**User Action:**
```
/identity query:Do my habits align with my personality?
```

**System Processing:**
1. Routes to IdentityAgent
2. Gathers:
   - Personality profile (INTJ, core values, life vision)
   - All habits with "why" fields
   - Big Five traits
3. Builds 7-step analysis prompt
4. AI analyzes alignment

#### Step 2: Identity Analysis Response
**User Sees:**
```
🧠 Habit-Identity Analysis from Identity Agent

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🎭 PERSONALITY ANALYSIS

Type: INTJ (Architect)
How INTJs form habits:
• Prefer structured, goal-oriented approaches
• Need to understand "why" behind actions
• Excel at long-term planning
• Value efficiency and optimization

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## ⚖️ VALUE ALIGNMENT

Core Values: Growth, Authenticity, Health

**High Alignment:**
• Morning Meditation → Health (100%)
  - "Build mental clarity" aligns perfectly
• Deep Work → Growth (95%)
  - "Become more productive" matches growth value

**Moderate Alignment:**
• Exercise → Health (75%)
  - Aligns with health but "why" is generic

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🎯 IDENTITY GAP ANALYSIS

Current Identity: Someone striving for growth
Desired Identity: "Lives intentionally, makes
                   daily progress without
                   sacrificing wellbeing"

Gap: Moderate (6/10)
• Meditation habit supports "intentional living"
• Deep work supports "daily progress"
• Need: Wellbeing protection mechanisms

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 📊 SCORING

Personality Score: 8/10
• Habits match INTJ preferences well
• Structured, goal-oriented approaches

Alignment Score: 7.5/10
• Strong value-habit connection
• Minor gaps in authenticity domain

Identity Evolution: Developing → Established

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 💡 RECOMMENDED HABITS

Based on INTJ + Core Values:

1. **Weekly Review** (Growth)
   - Aligns with: Planning, optimization
   - Implementation: Sunday evening reflection
   - Expected impact: +30% habit clarity

2. **Authentic Expression** (Authenticity)
   - Aligns with: Underutilized value
   - Implementation: Daily journaling
   - Expected impact: Close identity gap

3. **Rest & Recovery** (Health + Wellbeing)
   - Aligns with: Desired identity
   - Implementation: Scheduled downtime
   - Expected impact: Sustainable momentum

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Confidence: 0.82
```

### Journey 3: Accountability Agent

#### Step 1: Check-In Request
**User Action:**
```
I'm struggling to stay motivated this week
```

**System Processing:**
1. Personal Assistant classifies as accountability query
2. Routes to AccountabilityAgent
3. Agent analyzes:
   - Current week proofs
   - Consistency score
   - Motivation level indicators
   - Risk factors
4. Determines intervention type

#### Step 2: Accountability Response
**User Sees:**
```
💪 Accountability Check-In

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 📊 ASSESSMENT

Consistency Score: 6/10
• This week: 8/14 proofs (57%)
• Last week: 12/14 proofs (86%)
• Trend: Declining ↓

Motivation Level: 4/10
• Missed 2 consecutive days (Exercise)
• Completion rate dropped 29%

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🚨 RISK FACTORS

⚠️ Consecutive Misses: 2 days on Exercise
⚠️ Declining Trend: Week-over-week drop
⚠️ Pattern: Struggling on work days

Intervention Type: CHECK-IN

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 💬 LET'S TALK

I notice you're at 57% this week after a
strong 86% last week. That's a significant
dip, and I want to understand what changed.

**What's going on?**
- Work stress increased?
- Lost sight of your "why"?
- Goals feel too ambitious?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🎯 ONE THING FOR TOMORROW

Instead of all 3 habits, focus ONLY on:

**Morning Meditation (2 minutes)**
- Why: It's your highest success habit (100%)
- When: Right after waking up
- Reward: Coffee + sense of accomplishment

Just this one thing. Can you commit?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 🤝 SUPPORT OPTIONS

- Talk to your buddy: [Buddy name if assigned]
- Try a tool: /tools search:motivation
- Adjust goals: /mentor query:reduce difficulty
- Take a break: /pause if you need it

You've got this. One day at a time.

Confidence: 0.79
```

---

## 8. Sharing Learnings & Hurdles

### Journey 1: Share a Learning

#### Step 1: Post Learning
**User Action:**
```
/learning text:I discovered that meditating right after my alarm (before checking phone) is a game-changer. No willpower needed when it's the first thing I do.
```

**System Processing:**
1. Validates user exists
2. Creates learning in Notion Learnings database:
   - Discord ID (as title)
   - User relation
   - Habit relation (optional - not specified)
   - Text: [full learning text]
   - Created At: Now
3. Posts to #learnings-feed channel

#### Step 2: Confirmation
**User Sees (private):**
```
💡 Learning saved and shared!

Your insight has been posted to #learnings-feed
for the community to benefit from.

Other members can learn from your discovery!
```

**Community Sees (in #learnings-feed):**
```
💡 Marc shared a learning:

"I discovered that meditating right after my
alarm (before checking phone) is a game-changer.
No willpower needed when it's the first thing
I do."

Related to: Morning Meditation
```

### Journey 2: Document a Hurdle

#### Step 1: Post Hurdle
**User Action:**
```
/hurdles name:Forgetting to meditate type:Time Management description:When I wake up late, I skip my alarm and forget to meditate. By the time I remember, I'm already in work mode and feel too busy.
```

**System Processing:**
1. Validates user exists
2. Gets current batch
3. Filters user's habits by current batch
4. Creates hurdle in Notion Hurdles database:
   - Name: "Forgetting to meditate"
   - User relation
   - Habit relation (matched to Morning Meditation)
   - Hurdle Type: Time Management
   - Description: [full description]
   - Date: Today
5. Posts to #learnings-and-hurdles-feed

#### Step 2: Confirmation
**User Sees (private):**
```
🚧 Hurdle documented!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Forgetting to meditate
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Type: Time Management
Habit: Morning Meditation
Date: 2025-01-15

Your hurdle has been shared with the
community. Others may have solutions!

Try these:
• /tools search:habit stacking
• Ask your buddy for accountability
• /mentor for personalized strategies

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Community Sees (in #learnings-and-hurdles-feed):**
```
🚧 Marc is facing a hurdle:

**Forgetting to meditate**

Type: Time Management
Habit: Morning Meditation

"When I wake up late, I skip my alarm and
forget to meditate. By the time I remember,
I'm already in work mode and feel too busy."

💬 Reply with suggestions if you've overcome
   this challenge!
```

---

## 9. Weekly Challenges

### User Goal
Participate in weekly community challenges to earn rewards.

### Journey Overview

#### Saturday 3 PM: Poll Posted
**System Posts (in #weekly-challenges):**
```
🗳️ Vote for Next Week's Challenge!

React with the number of your choice:

1️⃣ Cold Shower Challenge
   Daily: 30-second cold shower
   Minimal: 10 seconds
   Days: 5/7
   Reward: €1

2️⃣ Digital Sunset Challenge
   Daily: No screens after 9 PM
   Minimal: No screens after 10 PM
   Days: 5/7
   Reward: €1

3️⃣ Morning Pages Challenge
   Daily: 750 words of journaling
   Minimal: 250 words
   Days: 5/7
   Reward: €1

4️⃣ Gratitude Practice Challenge
   Daily: Write 3 gratitudes
   Minimal: 1 gratitude
   Days: 5/7
   Reward: €1

5️⃣ Deep Work Sprint Challenge
   Daily: 90min focused work
   Minimal: 30min focused work
   Days: 5/7
   Reward: €1

Voting ends Sunday 9 AM!
```

#### User Votes
**User Action:**
Reacts with 1️⃣ (Cold Shower Challenge)

#### Sunday 9 AM: Previous Week Evaluated
**System Posts:**
```
🏆 Last Week's Challenge Results

**Productivity Power Hour Challenge**
(Week of Jan 6-12)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WINNERS (€1 reward each)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🥇 Marc - 7/7 proofs (100%)
🥈 Sarah - 6/7 proofs (86%)
🥉 Alex - 5/7 proofs (71%)
🏅 Tom - 5/7 proofs (71%)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PARTICIPANTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Marc - 7 proofs (5 full, 2 minimal)
2. Sarah - 6 proofs (6 full)
3. Alex - 5 proofs (4 full, 1 minimal)
4. Tom - 5 proofs (5 full)
5. Lisa - 3 proofs (3 full)

Total participants: 12
Total proofs: 53

Rewards have been credited to your accounts!
Check your balance with /balance
```

#### Sunday 3 PM: New Challenge Deployed
**System Posts:**
```
🎯 NEW WEEKLY CHALLENGE!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     Cold Shower Challenge
       (Community voted!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 Week: Jan 13 - Jan 19
🎁 Reward: €1 for completion

**Daily Requirement:**
30-second cold shower

**Minimal Dose:**
10 seconds cold water

**Days Required:** 5 out of 7

**Why try this?**
Cold showers boost:
• Mental resilience
• Energy levels
• Immune function
• Willpower

[Learn More](link)

                 [Join Challenge]

Submit proofs in this channel!
```

#### User Joins Challenge
**User Action:**
Clicks "Join Challenge" button

**System Responds:**
```
❄️ You've joined the Cold Shower Challenge!

Week: Jan 13-19
Goal: 5 cold showers (30 seconds each)
Minimal: 10 seconds accepted
Reward: €1

Submit proofs daily in #weekly-challenges:
- Post message (e.g., "Did 30s cold shower!")
- Or use /challenge proof command

Good luck! 💪
```

#### Wednesday 12 PM: Mid-Week Reminder
**System Posts:**
```
⏰ Mid-Week Challenge Reminder

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Cold Shower Challenge Progress
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Stats:
• Participants: 15
• Total proofs: 42
• Average: 2.8 proofs/person

🏆 On Track (≥3 proofs): 9 people
⚠️ Behind (<3 proofs): 6 people

You still have 4 days to complete!
Don't give up! ❄️💪
```

#### User Submits Proof
**User Action (in #weekly-challenges):**
```
Just did 45 seconds cold shower! Feeling alive! 🥶
```

**System Processing:**
1. ChallengeProofProcessor detects message
2. Validates:
   - User joined challenge? YES
   - Already submitted today? NO
   - Challenge active? YES
3. Creates proof in Notion Challenge Proofs DB:
   - Challenge Number: 3
   - Challenge Name: "Cold Shower Challenge"
   - User relation
   - Date: Today
   - Unit: "45 seconds"
   - Note: "Feeling alive!"
   - Is Minimal Dose: false (45s > 30s requirement)
   - Week Start: 2025-01-13
   - Week End: 2025-01-19

**User Sees:**
```
❄️ [Checkmark reaction]
Cold Shower proof logged! (4/5 completed)

1 more to earn your €1 reward! 🎁
```

#### Duplicate Proof Attempt
**User Action (same day):**
```
Did another cold shower!
```

**System Responds:**
```
⚠️ You already submitted a proof for today!

Challenge rules: One proof per day maximum.
Try again tomorrow! ❄️
```

---

## 10. Buddy System

### User Goal
Get paired with an accountability buddy for the 66-day batch.

### Journey: Batch Start with Buddy Assignment

#### Pre-Phase: Batch Created
**Admin Action:**
```
/batch start name:january2026 start-date:2026-01-01
```

**System Processing:**
1. Creates batch in `data/current-batch.json`:
   ```json
   {
     "name": "january2026",
     "createdDate": "2025-12-25",
     "startDate": "2026-01-01",
     "endDate": "2026-03-07",
     "status": "pre-phase"
   }
   ```
2. Announces in #accountability-group:
   ```
   📢 New Batch Created: January 2026

   Status: Pre-Phase
   Start Date: January 1, 2026 (7 days from now)
   End Date: March 7, 2026 (66 days)

   Join now with /join to secure your spot!
   Buddies will be assigned on Day 1.
   ```

#### Users Join During Pre-Phase
**User 1 (Marc) Action:**
```
/join
```
**Enrolled:** Marc added to batch "january2026"

**User 2 (Sarah) Action:**
```
/join
```
**Enrolled:** Sarah added to batch "january2026"

[More users join... total 8 users in batch]

#### Day 1: Batch Activation (January 1, 6:00 AM)
**System Processing:**
1. **DailyMessageScheduler** runs
2. Checks `shouldBatchStart()` → YES (today is Jan 1)
3. Updates batch status to "active"
4. Enrolls any remaining active users
5. **Triggers Buddy Assignment:**
   ```
   BuddyRotationScheduler.assignBuddiesForBatch("january2026")
   ```
6. **Buddy Assignment Process:**
   - Gets all users in batch where status = "active" (8 users)
   - Shuffles randomly: [Marc, Tom, Sarah, Lisa, Alex, Emma, John, Nina]
   - Pairs sequentially:
     - Pair 1: Marc ↔ Tom
     - Pair 2: Sarah ↔ Lisa
     - Pair 3: Alex ↔ Emma
     - Pair 4: John ↔ Nina
   - Updates Notion for each user:
     - Marc: buddy = "Tom", buddyStart = "2026-01-01"
     - Tom: buddy = "Marc", buddyStart = "2026-01-01"
     - [etc.]

#### Buddy Assignment Notifications
**Marc Sees (in #personal-marc):**
```
🤝 Buddy Assigned!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         January 2026 Batch
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your Accountability Buddy: Tom

You've been paired for the entire 66-day
batch to support each other's habit journey.

**Why Buddies?**
• 2x completion rate with peer accountability
• Mutual support during tough days
• Shared celebration of wins

**How to Buddy Well:**
• Check in regularly (2-3x per week)
• Share struggles and wins
• Encourage without judgment
• Celebrate each other's progress

Tom's habits:
1. Morning Workout
2. Reading
3. Healthy Cooking

Your buddy's progress will appear in your
weekly evaluations!

Ready to crush this together! 💪
```

**Tom Sees (in #personal-tom):**
```
🤝 Buddy Assigned!

Your Accountability Buddy: Marc

[Same message as above, but showing Marc's habits]
```

#### Buddy Check-In (During Batch)
**Week 3: Sunday 8 PM Weekly Evaluation**

**Marc's Weekly Analysis Includes Buddy Section:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 👥 BUDDY CHECK-IN: TOM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Overall: 78% completion this week

**Habits On Track:**
✅ Morning Workout (7/7 - 100%)
✅ Reading (5/7 - 71%)

**Needs Support:**
⚠️ Healthy Cooking (2/7 - 29%)
   • Missed target by 5 meals
   • Last proof: 4 days ago

Consider reaching out! Tom might appreciate
some encouragement on Healthy Cooking.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**If Buddy Struggling (<80%):**
```
🚨 BUDDY ATTENTION NEEDED

Tom missed his goal for "Healthy Cooking" this
week (2/7, 29% completion).

Specific issue:
• Target: 7 meals/week
• Actual: 2 meals
• Why: "Been ordering takeout due to work stress"

**Action:**
Send Tom a message of support!
Sometimes just knowing someone cares makes
all the difference.

[Message Tom]
```

#### Buddy Stays for Full 66 Days
- **No rotation** during batch
- Buddies stay together until batch completes
- New batch = new buddy assignments

---

## 11. Batch Participation

### User Goal
Understand and participate in the 66-day batch system.

### Journey 1: Joining Pre-Phase Batch

#### Step 1: Batch Announced
**Admin Creates Batch:**
```
/batch start name:march2026 start-date:2026-03-01
```

**System Posts (in #accountability-group):**
```
📢 NEW BATCH: March 2026

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Status: Pre-Phase ⏳
Start Date: March 1, 2026 (14 days from now)
End Date: May 5, 2026
Duration: 66 days

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT IS PRE-PHASE?

Pre-phase lets you:
• Join the batch early
• Create your habits before Day 1
• Build momentum
• Meet your future buddies

Batch officially starts March 1 with:
• Buddy assignments
• Daily motivational messages
• Weekly evaluations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Join now: /join
```

#### Step 2: User Joins
**User Action:**
```
/join
```

**User Sees:**
```
✅ Welcome to March 2026 Batch!

Status: Pre-Phase (starts in 14 days)

You can start creating habits now!
Type "keystone habit" in #personal-username

On Day 1 (March 1):
• You'll be assigned a buddy
• Daily motivation starts (6 AM)
• Weekly evaluations begin (Sunday 8 AM)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Batch Info: /batch info
```

#### Step 3: Check Batch Status
**User Action:**
```
/batch info
```

**User Sees:**
```
📊 Current Batch Information

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         March 2026 Batch
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Pre-Phase ⏳
Created: February 15, 2026
Start Date: March 1, 2026
End Date: May 5, 2026

Days Until Start: 14
Total Duration: 66 days

Enrolled Users: 12

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NEXT STEPS

1. Create your keystone habits
2. Optionally submit proofs (won't count yet)
3. Complete personality profile (/onboard)
4. Wait for batch activation (March 1)

On March 1 at 6 AM:
✅ Batch activates
✅ Buddies assigned
✅ Daily messages start
✅ 66-day journey begins!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

#### Step 4: Day 1 Activation
**March 1, 6:00 AM - System Processes:**
1. Checks `shouldBatchStart()` → YES
2. Updates batch status to "active"
3. Enrolls all active users
4. Assigns buddies (see Buddy System journey above)
5. Posts Day 1 message

**System Posts (in #accountability-group):**
```
🎉 DAY 1: MARCH 2026 BATCH ACTIVATED! 🎉

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Welcome to your 66-day transformation!

"We are what we repeatedly do. Excellence,
then, is not an act, but a habit."
- Aristotle

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TODAY'S FOCUS

Day 1 of 66 (65 days remaining)

✅ Submit your first proof
✅ Check in with your buddy
✅ Visualize Day 66 success

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT CHANGED TODAY

• Buddies assigned (check personal channel)
• Daily messages active (every 6 AM)
• Weekly evals start (Sunday 8 AM)
• Financial accountability begins

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The journey of 1,000 miles begins with
a single step. Take yours today! 🚀
```

**Users See (in personal channels):**
[Buddy assignment message as shown in Buddy System journey]

#### Step 5: Active Batch Experience
**Daily (6:00 AM):**
```
☀️ DAY 15 of 66

"Motivation is what gets you started.
Habit is what keeps you going."
- Jim Ryun

Days remaining: 51
You're 23% through your transformation!

Today's challenge: Submit proofs early,
build momentum for the rest of the day.

Keep going! 💪
```

**Weekly (Sunday 8:00 AM):**
```
[Weekly evaluation with trend graphs - see earlier journey]
```

**Weekly (Sunday 8:00 PM):**
```
[Financial accountability report - see earlier journey]
```

### Journey 2: Immediate Start Batch

#### Admin Creates Immediate Batch
**Admin Action:**
```
/batch start name:urgent-batch
```
(No start-date parameter = starts immediately)

**System Processing:**
1. Creates batch with status "active" immediately
2. Sets start date to today
3. Enrolls all active users right now
4. **Immediately assigns buddies**
5. Posts Day 1 message

**System Posts:**
```
🎉 BATCH STARTED: Urgent Batch

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This batch starts TODAY!

Day: 1 of 66
End Date: [66 days from today]
Enrolled Users: 8

Buddies have been assigned!
Check your personal channel.

Daily messages start tomorrow at 6 AM.
Weekly evaluations start this Sunday.

Let's go! 🚀
```

---

## 12. Pausing & Reactivating

### Journey 1: Pausing Participation

#### Step 1: Request Pause
**User Action (in personal channel):**
```
/pause reason:Going on vacation duration:2 weeks
```

**System Processing:**
1. Validates user in personal channel
2. Updates Notion Users DB:
   - Status: "pause"
   - Pause Reason: "Going on vacation"
   - Pause Duration: "2 weeks"

#### Step 2: Pause Confirmation
**User Sees:**
```
⏸️ Participation Paused

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Paused
Reason: Going on vacation
Expected Duration: 2 weeks

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT THIS MEANS

✅ Your habits are saved
✅ Your buddy remains assigned
❌ No weekly evaluations
❌ No financial accountability charges
❌ Not included in batch analytics

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

To resume: /activate

Enjoy your break! 🌴
```

#### Step 3: During Pause
**User Experience:**
- Can still submit proofs (saved to Notion)
- NOT included in weekly analyses
- NOT charged for missed habits
- Buddy progress NOT shown in evals
- Can chat in personal channel
- AI agents still available

### Journey 2: Reactivating

#### Step 1: Return from Pause
**User Action (in personal channel):**
```
/activate
```

**System Processing:**
1. Updates Notion Users DB:
   - Status: "active"
   - Clears pause reason and duration

#### Step 2: Activation Confirmation
**User Sees:**
```
▶️ Welcome Back!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Active ✅
Batch: March 2026
Current Day: 42 of 66
Buddy: Tom

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT HAPPENS NOW

✅ Weekly evaluations resume (next Sunday)
✅ Financial accountability active
✅ Included in batch analytics
✅ Buddy progress shown in evals

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
JUMP BACK IN

1. Check /summary to see current status
2. Submit today's proofs
3. Check in with your buddy (Tom)
4. Review habits - still aligned? /mentor

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Ready to finish strong! 💪
24 days left in the batch!
```

---

## 13. Using Habit Tools

### User Goal
Get research-backed strategies to overcome habit formation challenges.

### Journey: Finding Tools for a Problem

#### Step 1: Post Problem in Tools Channel
**User Action (in #tools):**
```
I keep forgetting to start my meditation habit in the mornings
```

**System Processing:**
1. ToolsAssistant detects message in tools channel
2. Sends problem + all 40 tools to Perplexity AI
3. AI performs semantic matching
4. Returns top 1-2 most relevant tools

#### Step 2: AI Tool Recommendations
**User Sees:**
```
🧰 Habit Tools Recommendations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 1. Habit Stacking
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Why this tool:**
Habit Stacking creates automatic triggers
by linking your new habit to an existing
routine. Since you're "forgetting," you need
a reliable cue that happens every morning
without thinking.

**How to Apply:**

1. **Identify anchor habit**
   Find something you ALWAYS do every morning
   (e.g., "After I turn off my alarm...")

2. **Create the stack**
   Formula: "After [ANCHOR], I will [NEW HABIT]"
   Example: "After I turn off my alarm, I will
   sit up and take 3 deep breaths"

3. **Make it obvious**
   Place meditation cushion next to bed so you
   see it immediately after alarm

**Learn More:**
James Clear - Atomic Habits (Chapter 5)
https://jamesclear.com/habit-stacking

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## 2. Environmental Triggers
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Why this tool:**
Your environment shapes behavior automatically.
If meditation tools are visible, you're more
likely to remember without relying on memory.

**How to Apply:**

1. **Create visual cue**
   Place meditation cushion in your path when
   you wake up (literally can't miss it)

2. **Reduce friction**
   Pre-set meditation app on phone the night
   before (open and ready to start)

3. **Automate reminder**
   Set phone to "Do Not Disturb" EXCEPT for
   one alarm labeled "Meditation Time"

**Learn More:**
BJ Fogg - Tiny Habits
https://tinyhabits.com

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 This suggestion has been saved to your
   learnings for future reference!
```

**If user is registered, system also:**
- Saves tool suggestion as learning in Notion
- Links to user's meditation habit
- Logs interaction for future reference

#### Alternative Search Patterns

**Specific Tool Search:**
```
User: "Tell me about the Pomodoro Technique"
Bot: [Returns detailed Pomodoro tool info]
```

**Category Search:**
```
User: "What tools help with motivation?"
Bot: [Returns Temptation Bundling, Reward System,
      Identity-Based Habits]
```

**Hurdle-Based Search:**
```
User: "I'm too tired in the evenings to exercise"
Bot: [Returns Energy Management, Morning Habits,
      Habit Scheduling tools]
```

---

## 14. Personal Assistant Interactions

### User Goal
Chat naturally with AI assistant to get personalized guidance.

### Journey 1: Simple Question

#### Step 1: Ask Question
**User Action (in personal channel):**
```
How many days have I meditated this week?
```

**System Processing:**
1. QueryClassifier analyzes message
2. Intent: "progress_check"
3. Mentioned habits: ["meditated" → "Morning Meditation"]
4. DynamicContextBuilder loads:
   - Summary statistics
   - This week's proofs (filtered for meditation)
5. Compresses context to ~500 tokens
6. Sends to Perplexity with system prompt

#### Step 2: AI Response
**User Sees:**
```
📊 Based on your Notion data:

**Morning Meditation this week:**
• Completed: 4 days
• Target: 5 days (Mon-Fri)
• Progress: 80%

**Details:**
✅ Monday - 10 minutes
✅ Tuesday - 10 minutes
✅ Wednesday - 2 minutes (minimal dose)
✅ Thursday - 10 minutes
❌ Friday - Not yet (today)

You're on track! Submit today's proof to
hit 100% for the week. 🎯
```

### Journey 2: Habit Analysis Question

#### Step 1: Complex Query
**User Action:**
```
Why am I struggling with deep work compared to my other habits?
```

**System Processing:**
1. Intent: "habit_analysis"
2. Mentioned habits: ["deep work" → "Deep Work"]
3. Loads:
   - Habits Overview section from profile
   - Personality Profile section
   - Current week proofs (all habits for comparison)
   - Summary keywords
4. Compresses to fit budget
5. AI analyzes with comparison context

#### Step 2: AI Deep Analysis
**User Sees:**
```
🧠 Analyzing "Deep Work" vs. other habits:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## PERFORMANCE COMPARISON
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

| Habit      | This Week | Frequency | Success |
|------------|-----------|-----------|---------|
| Meditation | 5/5       | 5x/week   | 100%    |
| Deep Work  | 3/7       | 7x/week   | 43%     |
| Exercise   | 2/5       | 5x/week   | 40%     |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## WHY DEEP WORK IS HARDER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Frequency Mismatch:**
• Meditation: 5x/week (weekdays only)
• Deep Work: 7x/week (EVERY day)
• Weekend completion: 0/2

Your Notion data shows Deep Work has NO
weekend proofs in the last 4 weeks.

**Why this matters:**
Meditation benefits from your weekday
routine. Deep Work requires weekend effort,
which your current environment doesn't
support (family time, relaxation mode).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## PERSONALITY INSIGHTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

As an INTJ:
• You excel at structured routines (Meditation)
• Weekends lack structure → habits fail
• Deep Work needs clear time boundaries

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## RECOMMENDATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. **Reduce frequency** to 5x/week (weekdays)
   Align with your existing routine

2. **OR protect weekend slots** explicitly
   Saturday 8-9 AM = Sacred Deep Work Hour

3. **Stack with existing habit**
   "After meditation, I will do 30min deep work"

Try option 1 first (easier path).

Want to adjust your goal? Use /mentor
```

### Journey 3: Mood Check

#### Step 1: User Shares Feelings
**User Action:**
```
Feeling discouraged today, missed several habits this week
```

**System Processing:**
1. Intent: "general" (no specific question)
2. Detects emotional tone
3. Loads summary + this week's context
4. Personalizes empathetic response

#### Step 2: Supportive Response
**User Sees:**
```
💬 I hear you, Marc.

Looking at your week, you completed 10/17
target proofs (59%). That's below your usual
85% average, so feeling discouraged makes sense.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**What the data shows:**
• Monday-Wednesday: 9/9 (100%) 🔥
• Thursday-Friday: 1/8 (13%) 📉

Something shifted mid-week. Work stress?
Energy crash? External circumstances?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Here's what I want you to remember:**

1. **You DID show up** (10 proofs completed)
   That's 10 more than someone who quit.

2. **You have a 21-day best streak**
   That proof of capability lives in your data.

3. **One tough week ≠ failure**
   Your 66-day journey = ~9 weeks
   This is 1 of them.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**For tomorrow:**
Just do ONE habit. Pick your easiest win
(Morning Meditation - 2 min minimal dose).

One proof. That's all. Can you do that?

If you need to pause the system temporarily,
that's okay too (/pause). But don't quit.

Talk to your buddy (Tom) - he's here for this.

I'm here for you. 💙
```

---

## 15. Admin: Creating a Batch

### User Goal (Admin)
Create and manage 66-day batches for the community.

### Journey: Creating a Pre-Phase Batch

#### Step 1: Admin Creates Batch
**Admin Action (in #admin channel):**
```
/batch start name:april2026 start-date:2026-04-01
```

**System Processing:**
1. Validates admin channel
2. Validates date format (YYYY-MM-DD)
3. Checks if date is in future → YES
4. Creates batch in `data/current-batch.json`:
   ```json
   {
     "name": "april2026",
     "createdDate": "2026-03-15",
     "startDate": "2026-04-01",
     "endDate": "2026-06-05",
     "status": "pre-phase"
   }
   ```
5. Posts announcements

#### Step 2: Batch Created Confirmation
**Admin Sees (in #admin):**
```
✅ Batch Created Successfully

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         April 2026 Batch
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Pre-Phase ⏳
Created: March 15, 2026
Start Date: April 1, 2026 (17 days from now)
End Date: June 5, 2026 (66 days)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NEXT STEPS

1. Announcement posted to #accountability-group
2. Users can join with /join
3. Batch auto-activates on April 1 at 6 AM
4. Buddies auto-assigned on activation

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Monitor with: /batch info
```

**All Users See (in #accountability-group):**
```
📢 NEW BATCH: April 2026

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Pre-Phase (starts in 17 days)
Start: April 1, 2026
End: June 5, 2026
Duration: 66 days

Join early with /join to:
• Create habits before Day 1
• Build momentum in pre-phase
• Be ready when batch activates

Buddies assigned on Day 1 (April 1)!
```

#### Step 3: Monitor Batch
**Admin Action:**
```
/batch info
```

**Admin Sees:**
```
📊 Current Batch Information

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         April 2026 Batch
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Pre-Phase ⏳
Created: March 15, 2026
Start Date: April 1, 2026
End Date: June 5, 2026

Days Until Start: 17
Enrolled Users: 15

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRE-PHASE ACTIVITY

Habits Created: 23
Proofs Submitted: 47 (not counted yet)
Profiles Completed: 12

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Batch activates automatically on April 1 at 6 AM.
Daily scheduler will:
✅ Update status to "active"
✅ Assign buddies
✅ Start daily messages
✅ Begin weekly evaluations
```

#### Step 4: Day 1 Automatic Activation
**April 1, 6:00 AM - System Auto-Processes:**
1. DailyMessageScheduler checks `shouldBatchStart()`
2. Detects April 1 arrived
3. Updates status to "active"
4. Assigns buddies to all 15 users
5. Posts Day 1 message
6. Logs all actions to info channel

**Admin Sees (in #admin and #info-channel):**
```
🎉 BATCH ACTIVATED: April 2026

Status: Active ✅
Start Date: April 1, 2026 (TODAY)
End Date: June 5, 2026
Enrolled Users: 15
Buddy Pairs: 7 pairs (1 user unpaired - odd number)

Actions Completed:
✅ Batch status updated
✅ Buddies assigned and notified
✅ Day 1 message posted
✅ Daily scheduler active
✅ Weekly schedulers active

All systems operational for 66-day journey!
```

---

## Conclusion

This comprehensive user journey documentation covers all major features of the Discord Habit System. Each journey demonstrates:

1. **User actions** - What users type/click
2. **System processing** - Behind-the-scenes logic
3. **User feedback** - What users see and experience
4. **Edge cases** - Alternative flows and error states
5. **Integration** - How features connect

The system provides a seamless, AI-powered habit tracking experience with multiple entry points, intelligent automation, and comprehensive support for the 66-day transformation journey.
