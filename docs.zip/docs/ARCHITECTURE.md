# Discord Habit System - Complete Architecture Documentation

## Executive Summary

The Discord Habit System is a production-ready habit tracking platform built on Discord with Notion integration, following the 66-day challenge framework. The system combines automated proof logging, AI-driven message analysis, multi-agent coordination, and personal assistant features to help users build and maintain keystone habits.

**Architecture Highlights:**
- **53 TypeScript files** (13,022 lines in bot layer alone)
- **10 Notion databases** with comprehensive schema
- **5 specialized AI agents** using Perplexity Sonar model
- **6 automated schedulers** running on node-cron
- **19 slash commands** serving active users
- **Docker deployment** with 460MB optimized image
- **Multi-agent coordination** with TypeScript + Python CrewAI

---

## System Architecture Overview

```
┌───────────────────────────────────────────────────────────────────┐
│                        DISCORD CLIENT                              │
│                      (discord.js v14)                              │
└────────────┬──────────────────────────────────────────────────────┘
             │
             ↓
┌───────────────────────────────────────────────────────────────────┐
│                    HABIT BOT (Main Orchestrator)                   │
│                     src/bot/bot.ts (1,486 lines)                   │
├───────────────────────────────────────────────────────────────────┤
│  Event Handlers:                                                   │
│  • messageCreate → Unified message processing pipeline            │
│  • interactionCreate → Commands, modals, buttons                  │
│  • ready → Initialize schedulers and systems                      │
│  • messageReactionAdd → Proof validation                          │
└────┬──────────────────────────────────────────────────────────────┘
     │
     ├─────→ Command Handler (commands.ts)
     │       ├─ User Commands (/join, /proof, /summary, etc.)
     │       ├─ Profile Commands (/onboard, /profile, /profile-edit)
     │       ├─ Community Commands (/learning, /hurdles, /tools)
     │       └─ Agent Commands (/mentor, /identity, /accountability)
     │
     ├─────→ Admin Command Handler (admin-commands.ts)
     │       ├─ /batch start → Create new 66-day batch
     │       └─ /batch info → Show current batch status
     │
     ├─────→ Personal Channel Manager (personal-channel-manager.ts)
     │       └─ Creates private channels for each user
     │
     ├─────→ Habit Flow Manager (habit-flow.ts)
     │       └─ 4-step modal flow for keystone habit creation
     │
     ├─────→ Proof Processor (proof-processor.ts)
     │       ├─ Manual submissions via /proof
     │       └─ Automatic detection from messages
     │
     ├─────→ Message Analyzer (message-analyzer.ts)
     │       └─ AI classification via Perplexity Sonar
     │
     ├─────→ Personal Assistant (personal-assistant.ts)
     │       ├─ Profile generation
     │       ├─ Query classification
     │       └─ Context-aware responses
     │
     ├─────→ Tools Assistant (tools-assistant.ts)
     │       └─ Semantic tool matching (40+ habit tools)
     │
     ├─────→ Channel Handlers (channel-handlers.ts)
     │       └─ Routes messages to appropriate processors
     │
     ├─────→ Discord Logger (discord-logger.ts)
     │       └─ Centralized logging to info channel
     │
     └─────→ Schedulers (6 automated cron jobs)
             ├─ DailyMessageScheduler (6 AM daily)
             ├─ AIIncentiveManager (Sunday 8 AM)
             ├─ AccountabilityScheduler (Sunday 8 PM)
             ├─ ChallengeScheduler (Sat/Sun/Wed)
             ├─ MidWeekScheduler (Wednesday 8 PM)
             └─ WebhookPoller (10-second intervals)

┌───────────────────────────────────────────────────────────────────┐
│                     MULTI-AGENT SYSTEM                             │
│                   src/agents/ (11 TypeScript files)                │
├───────────────────────────────────────────────────────────────────┤
│  Orchestrator (orchestrator.ts)                                    │
│    ├─ Routes requests to appropriate agents                       │
│    ├─ Agent selection based on scoring                            │
│    └─ Response aggregation                                        │
│                                                                    │
│  Specialized Agents:                                               │
│    ├─ MentorAgent (mentor_agent.ts) - Habit coaching              │
│    ├─ IdentityAgent (identity_agent.ts) - Personality matching    │
│    ├─ AccountabilityAgent (accountability_agent.ts) - Motivation  │
│    ├─ GroupAgent (group_agent.ts) - Social dynamics               │
│    ├─ LearningAgent (learning_agent.ts) - Pattern mining          │
│    └─ AccountabilityMoneyAgent - Financial accountability         │
│                                                                    │
│  Base Framework:                                                   │
│    ├─ BaseAgent (base/agent.ts) - Abstract base class             │
│    ├─ AgentRegistry - Singleton agent management                  │
│    └─ Types (base/types.ts) - 230+ type definitions               │
└────┬──────────────────────────────────────────────────────────────┘
     │
     └─────→ Perplexity AI Client (ai/perplexity-client.ts)
             └─ Sonar model with failover strategy

┌───────────────────────────────────────────────────────────────────┐
│                    PYTHON CREWAI AGENTS                            │
│                  python-agents/ (Flask API)                        │
├───────────────────────────────────────────────────────────────────┤
│  Flask API (api.py) - Port 8000                                    │
│    └─ /analyze/midweek endpoint                                   │
│                                                                    │
│  MidWeek Agent (midweek_agent.py)                                 │
│    ├─ CrewAI framework                                             │
│    ├─ Perplexity LLM (llama-3.1-sonar-large-128k-online)          │
│    └─ Notion Tool for data access                                 │
│                                                                    │
│  Notion Tool (tools/notion_tool.py)                                │
│    ├─ get_active_users()                                           │
│    ├─ get_user_habits()                                            │
│    ├─ get_user_proofs()                                            │
│    └─ get_midweek_analysis_data()                                 │
└────┬──────────────────────────────────────────────────────────────┘
     │
     └─────→ CrewAI Client (src/agents/crewai-client.ts)
             └─ HTTP bridge to Python agents

┌───────────────────────────────────────────────────────────────────┐
│                      NOTION INTEGRATION                            │
│                  src/notion/client.ts (2,261 lines)                │
├───────────────────────────────────────────────────────────────────┤
│  10 Notion Databases:                                              │
│                                                                    │
│  1. Users DB                                                       │
│     ├─ Discord ID, Name, Status (active/pause)                    │
│     ├─ Personal Channel ID, Trust Count                           │
│     ├─ Buddy, BuddyStart, Batch enrollment                        │
│     └─ Methods: createUser(), getUserByDiscordId(), etc.          │
│                                                                    │
│  2. Habits DB                                                      │
│     ├─ Name, User relation, SMART Goal, Minimal Dose              │
│     ├─ Frequency (1-7), Selected Days, Batch                      │
│     └─ Methods: createHabit(), getHabitsByUserId()                │
│                                                                    │
│  3. Proofs DB                                                      │
│     ├─ User, Habit, Date, Unit, Note                              │
│     ├─ Is Minimal Dose, Is Cheat Day, Batch                       │
│     └─ Methods: createProof(), getProofsByUserId()                │
│                                                                    │
│  4. Learnings DB                                                   │
│     ├─ Discord ID, User, Habit, Text, Created At                  │
│     └─ Methods: createLearning(), getLearningsByUserId()          │
│                                                                    │
│  5. Hurdles DB                                                     │
│     ├─ Name, User, Habit, Hurdle Type, Description                │
│     └─ Methods: createHurdle(), getHurdlesByUserId()              │
│                                                                    │
│  6. Weeks DB                                                       │
│     ├─ Discord ID, User, Week Num, Start Date                     │
│     ├─ Summary (AI-generated), Score                              │
│     └─ Methods: createWeek(), getWeeksByUserId()                  │
│                                                                    │
│  7. Groups DB                                                      │
│     ├─ Name, Channel ID, Donation Pool                            │
│     └─ Methods: createGroup(), getAllGroups()                     │
│                                                                    │
│  8. Personality DB                                                 │
│     ├─ Discord ID, User, Personality Type, Core Values            │
│     ├─ Life Vision, Main Goals, Big Five Traits                   │
│     ├─ Life Domains, Life Phase, Desired Identity                 │
│     └─ Methods: createUserProfile(), getUserProfileByDiscordId()  │
│                                                                    │
│  9. Price Pool DB                                                  │
│     ├─ Discord ID, User, Week Date, Message                       │
│     ├─ Price (€0.50 per missed habit), Batch                      │
│     └─ Methods: createPricePoolEntry(), getTotalPricePool()       │
│                                                                    │
│  10. Challenge Proofs DB                                           │
│      ├─ Title, Challenge Number, Challenge Name                   │
│      ├─ User, Date, Unit, Note, Is Minimal Dose                   │
│      ├─ Week Start, Week End                                      │
│      └─ Methods: createChallengeProof(), getChallengeProofsByWeek│
└────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────┐
│                        UTILITIES & TOOLS                           │
├───────────────────────────────────────────────────────────────────┤
│  Batch Manager (utils/batch-manager.ts)                            │
│    ├─ getCurrentBatch() - Get active batch from JSON              │
│    ├─ getCurrentBatchDay() - Calculate day 1-66                   │
│    ├─ shouldBatchStart() - Check if pre-phase should activate     │
│    └─ File-based storage: data/current-batch.json                 │
│                                                                    │
│  Trend Graph Generator (utils/trend-graph-generator.ts)            │
│    ├─ Generates PNG charts with Canvas library                    │
│    ├─ Week calculation from first proof date                      │
│    ├─ Color-coded trends (blue/red/gray)                          │
│    └─ Dynamic sizing (800-1600px width)                           │
│                                                                    │
│  Challenge Manager (bot/challenge-manager.ts)                      │
│    ├─ 20 pre-defined weekly challenges                            │
│    ├─ Categories: Productivity, Life, Biohacking, CEO             │
│    └─ Challenge rotation and selection                            │
│                                                                    │
│  Challenge State Manager (bot/challenge-state.ts)                  │
│    ├─ In-memory challenge state                                   │
│    ├─ Current week tracking                                       │
│    └─ Participant management                                      │
│                                                                    │
│  Toolbox (toolbox/)                                                │
│    ├─ 40+ habit formation tools                                   │
│    ├─ Research-backed techniques                                  │
│    └─ Semantic matching capabilities                              │
└────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────┐
│                      DEPLOYMENT (Docker)                           │
├───────────────────────────────────────────────────────────────────┤
│  Container: habit-discord-bot:optimized (460MB)                    │
│    ├─ Base: Node.js 18 Alpine Linux                               │
│    ├─ Multi-stage build for optimization                          │
│    ├─ Non-root user (node)                                        │
│    └─ Health checks every 30s                                     │
│                                                                    │
│  Volumes:                                                          │
│    ├─ ./logs → /app/logs (persistent logs - 560KB)                │
│    └─ ./data → /app/data (profiles, state - 40KB)                 │
│                                                                    │
│  Resource Limits:                                                  │
│    ├─ Memory: 256M-512M                                            │
│    └─ CPU: 0.25-0.5 cores                                          │
│                                                                    │
│  Scripts:                                                          │
│    ├─ deploy.sh - Build and deploy                                │
│    ├─ update-and-deploy.sh - Git pull + deploy                    │
│    └─ docker-commands.sh - Container management                   │
└────────────────────────────────────────────────────────────────────┘
```

---

## Core Components Breakdown

### 1. Entry Point & Initialization

**File:** `src/index.ts`

**Startup Sequence:**
1. Load environment variables (dotenv)
2. Validate 21 required env vars
3. Initialize NotionClient with 10 database IDs
4. Create HabitBot instance
5. Register slash commands with Discord
6. Start bot and connect to Discord

**Environment Variables Required:**
- Discord: BOT_TOKEN, CLIENT_ID, GUILD_ID
- Channels: ACCOUNTABILITY_GROUP, PERSONAL_CHANNEL, INFO_CHANNEL, TOOLS, WEEKLY_CHALLENGES, ADMIN, LOG_CHANNEL
- Notion: TOKEN + 10 database IDs
- AI: PERPLEXITY_API_KEY

---

### 2. Main Bot Orchestrator

**File:** `src/bot/bot.ts` (1,486 lines)

**Core Responsibilities:**
- Event handling (messages, interactions, reactions)
- Scheduler initialization
- Agent system coordination
- Command routing
- Channel management

**Event Handling Priority:**
1. Webhook detection (FIRST, before bot filter)
2. Bot message filter
3. Message logging via DiscordLogger
4. Habit flow detection ("KeystoneHabit")
5. Personal assistant (personal channel)
6. Challenge proofs (weekly challenges channel)
7. Tools assistant (tools channel)
8. Proof processor (accountability channel)

---

### 3. Command System

**Files:**
- `src/bot/commands.ts` - User commands
- `src/bot/admin-commands.ts` - Admin commands

**Command Categories:**

**User Commands (16):**
- Registration: /join
- Habit tracking: /proof, /summary
- Profile: /onboard, /profile, /profile-edit
- Community: /learning, /hurdles, /tools
- AI agents: /mentor, /identity, /accountability, /group, /learning-agent
- User management: /pause, /activate

**Admin Commands (2):**
- /batch start [name] [start-date?]
- /batch info

**Command Handler Features:**
- Modal chaining with 5-minute cache
- Context validation
- Error handling with user-friendly messages
- Integration with PersonalChannelManager
- Notion database operations

---

### 4. Proof Processing System

**File:** `src/bot/proof-processor.ts`

**Proof Sources:**
1. **Manual:** `/proof` command
2. **Automatic:** Accountability channel messages via AI classification

**Processing Flow:**
```
Message → ProofProcessor
    ↓
getUserByDiscordId() / resolveWebhookUser()
    ↓
getHabitsByUserId() + filterByCurrentBatch()
    ↓
AI Classification (Perplexity Sonar)
    ├─ Extract habit name
    ├─ Extract unit/quantity
    └─ Extract notes
    ↓
matchHabit() - Fuzzy matching
    ↓
Validate minimal dose
    ↓
createProof() → Notion Proofs DB
    ↓
React with emoji (✅, ⭐, or 🎯)
    ↓
Send confirmation message
```

**Features:**
- Webhook user resolution (matches webhook name to Notion user)
- Deduplication via in-flight message tracking
- Minimal dose validation
- Batch filtering (only current batch habits)
- AI-powered habit matching with synonym support

---

### 5. Habit Creation Flow

**File:** `src/bot/habit-flow.ts`

**Trigger:** User types "KeystoneHabit" (or variations) in personal channel

**4-Step Modal Flow:**

**Modal 1: Basics**
- Name (100 chars)
- Domains (200 chars, comma-separated)
- Context (1000 chars)
- Difficulty (easy/medium/hard)

**Day Selector (Interactive Buttons)**
- 7 day buttons (Mon-Sun)
- Toggle selection (⭕ → ✅)
- Continue button (disabled until ≥1 day selected)

**Modal 2: Goals & Motivation**
- SMART Goal (1000 chars)
- Epic Meaning (1000 chars)
- Minimal Dose (200 chars)
- Habit Loop (1000 chars)
- Consequences (1000 chars)

**Modal 3: Reflection & Planning**
- Curiosity/Passion/Purpose (1000 chars)
- Autonomy (1000 chars)
- Hurdles (1000 chars)
- Reminder Type (200 chars)

**Modal 4: 66-Day Commitment**
- Signature field: "I commit" (validation required)
- Saves complete habit to Notion
- Assigns current batch
- Sends celebration message with GIF

**Features:**
- Session management (5-minute cache)
- Data chaining across modals
- Batch integration
- Frequency calculation from selected days
- Error recovery with clear messages

---

### 6. Personal Channel Management

**File:** `src/bot/personal-channel-manager.ts`

**Functions:**
- Creates private channels (format: `personal-{username}`)
- Sets permissions (user + bot only)
- Sends welcome message with personality questionnaire
- Stores channel ID in Notion

**Channel Usage:**
- Personal assistant interactions
- Habit creation flows
- Weekly evaluations
- Direct user-bot communication

---

### 7. Message Analyzer (AI Classification)

**File:** `src/bot/message-analyzer.ts`

**Purpose:** Automatically classify and extract data from natural language messages

**AI Model:** Perplexity Sonar

**Classification Types:**
- **proof:** Habit completion evidence
- **question:** User query
- **learning:** Insight or discovery
- **hurdle:** Obstacle or challenge
- **general:** Other messages

**Semantic Matching Features:**
- Partial habit name matching
- Synonym support (deep work, meditation, exercise, etc.)
- Activity pattern recognition (time + activity)
- Scoring system with confidence thresholds
- Fallback to rule-based matching

**Data Extraction:**
- Habit name
- Unit/quantity
- Notes
- Minimal dose indicator
- Cheat day indicator

---

### 8. Personal Assistant

**File:** `src/bot/personal-assistant.ts`

**Capabilities:**
- Profile generation (Markdown format)
- Query classification (6 intent types)
- Dynamic context building
- Context compression
- AI-powered responses (Perplexity Sonar)

**Query Intent Types:**
1. **habit_analysis:** Questions about habits, frequency, performance
2. **progress_check:** Current progress, streaks, this week
3. **personality_advice:** Habit-personality alignment
4. **hurdle_help:** Obstacles, problems, stuck
5. **learning_insight:** Patterns, learnings, what works
6. **general:** All other questions

**Profile System:**
- Auto-generates profiles for all users
- Stores in `/data/profiles/` directory
- Hash-based change detection
- 24-hour cache
- Periodic updates (hourly check)

**Context Optimization:**
- Intent-based data loading
- Token budget management (≤2000 tokens)
- Smart truncation at word boundaries
- Keyword blocks for compactness

---

### 9. Tools Assistant

**File:** `src/bot/tools-assistant.ts`

**Purpose:** Semantic matching of user problems to habit formation tools

**Tool Database:** 40+ research-backed techniques including:
- Routine: Habit Stacking, Time Boxing, Micro-Habits
- Focus: Deep Work, Pomodoro, Digital Minimalism
- Motivation: Temptation Bundling, Reward System
- Environment: Environment Design, Dedicated Space
- Obstacles: 5 Whys, Obstacle Mapping

**Matching Strategy:**
1. AI semantic matching (Perplexity)
2. Rule-based fallback (keywords)
3. Dual language support (English/German)

**Output:**
- Tool name and summary
- AI reasoning for match
- 3-5 actionable steps
- Research sources (James Clear, BJ Fogg, Cal Newport)

---

### 10. Multi-Agent System

**Files:** `src/agents/` (11 TypeScript files)

**Architecture:**
- **Orchestrator:** Routes requests, selects agents, aggregates responses
- **BaseAgent:** Abstract class with common capabilities
- **AgentRegistry:** Singleton managing agent lifecycle
- **Type System:** 230+ type definitions

**Specialized Agents:**

**MentorAgent (mentor_agent.ts):**
- Role: Habit coaching and pattern analysis
- Capabilities: habit_analysis, pattern_recognition, coaching_advice
- Features: Adaptive goals system, multi-week trend analysis
- Output: Weekly analysis with recommendations

**IdentityAgent (identity_agent.ts):**
- Role: Personality-habit alignment
- Capabilities: personality_analysis, habit_identity_matching
- Features: Big Five integration, identity evolution tracking
- Output: Personality score, alignment score, recommendations

**AccountabilityAgent (accountability_agent.ts):**
- Role: Progress monitoring and motivation
- Capabilities: adaptive_reminders, motivation_management
- Features: Risk detection, intervention classification
- Output: Consistency assessment, intervention messages

**GroupAgent (group_agent.ts):**
- Role: Social dynamics and coordination
- Capabilities: group_formation, peer_influence_analysis
- Features: Compatibility scoring, buddy recommendations
- Output: Social opportunities, risk factors

**LearningAgent (learning_agent.ts):**
- Role: Pattern mining and knowledge synthesis
- Capabilities: pattern_recognition, solution_generation
- Features: Cross-user analytics, hurdle analysis
- Output: Insights with confidence scores

**AccountabilityMoneyAgent:**
- Role: Financial accountability
- Capabilities: habit_compliance_tracking, leaderboard_generation
- Features: €0.50 per missed habit, weekly reports
- Output: Charges, leaderboard, pool balance

---

### 11. Python CrewAI Agents

**Files:** `python-agents/`

**MidWeek Agent (midweek_agent.py):**
- Framework: CrewAI
- LLM: Perplexity (llama-3.1-sonar-large-128k-online)
- Schedule: Wednesday 8 PM
- Purpose: Team dynamics analysis

**Notion Tool (tools/notion_tool.py):**
- CrewAI BaseTool for Notion data access
- Operations: get_active_users, get_user_habits, get_user_proofs
- Batch-aware filtering

**Flask API (api.py):**
- Port: 8000
- Endpoints: /analyze/midweek, /health
- Integration: TypeScript bot via HTTP

---

### 12. Scheduler System

**6 Automated Cron Jobs:**

**1. DailyMessageScheduler**
- Schedule: 6:00 AM daily
- Function: Motivational quotes, batch activation check
- File: `src/bot/daily-message-scheduler.ts`

**2. AIIncentiveManager**
- Schedule: Sunday 8:00 AM
- Function: Weekly evaluations with trend graphs
- File: `src/bot/ai-incentive-manager.ts`

**3. AccountabilityScheduler**
- Schedule: Sunday 8:00 PM
- Function: Financial accountability reports
- File: `src/bot/accountability-scheduler.ts`

**4. ChallengeScheduler**
- Schedules: Saturday 3 PM, Sunday 9 AM/3 PM, Wednesday 12 PM
- Function: Weekly challenge management
- File: `src/bot/challenge-scheduler.ts`

**5. MidWeekScheduler**
- Schedule: Wednesday 8:00 PM
- Function: CrewAI team analysis
- File: `src/bot/midweek-scheduler.ts`

**6. WebhookPoller**
- Interval: Every 10 seconds
- Function: Accountability channel monitoring
- File: `src/bot/webhook-poller.ts`

---

### 13. Batch Management System

**File:** `src/utils/batch-manager.ts`

**Storage:** File-based (`data/current-batch.json`)

**Batch Lifecycle:**
1. **Pre-Phase:** Created with future start date, users can join early
2. **Day 1 Activation:** Daily scheduler checks and transitions to "active"
3. **Active (Days 1-66):** All systems operational
4. **Completion:** Day 66+, batch marked "completed"

**Key Functions:**
- `getCurrentBatch()` - Returns active batch or null
- `getCurrentBatchDay()` - Calculates day 1-66
- `shouldBatchStart()` - Checks if pre-phase should activate
- `isBatchActive()` - Boolean check

**Buddy Assignment:**
- Triggered once at batch start (Day 1)
- Pre-phase batches: Daily scheduler activates and assigns
- Immediate batches: `/batch start` assigns immediately
- Buddies stay together for full 66 days

---

### 14. Trend Graph Generator

**File:** `src/utils/trend-graph-generator.ts`

**Technology:** Canvas (node-canvas)

**Features:**
- PNG image generation
- Week calculation from first proof (not calendar weeks)
- Minimum 4 weeks of data required
- Dynamic sizing (800-1600px width)
- Color-coded trends:
  - Blue: Improving
  - Red: Declining
  - Gray: Stable

**Components:**
- Grid lines (5 horizontal + vertical per week)
- X-axis: Week numbers
- Y-axis: Proof counts
- Data points with trend lines
- Title and labels

---

### 15. Notion Client

**File:** `src/notion/client.ts` (2,261 lines)

**10 Databases:**
1. Users - User profiles and status
2. Habits - Habit definitions
3. Proofs - Daily completions
4. Learnings - User insights
5. Hurdles - Obstacles
6. Weeks - Weekly summaries
7. Groups - Team cohorts
8. Personality - User profiles
9. Price Pool - Financial accountability
10. Challenge Proofs - Weekly challenge submissions

**Key Operations:**
- CRUD operations for all databases
- Batch-aware filtering
- Buddy progress tracking
- Challenge management
- User summaries and analytics

---

### 16. Discord Logger

**File:** `src/bot/discord-logger.ts`

**Purpose:** Centralized logging to Discord info channel

**Log Types:**
- INFO (blue)
- SUCCESS (green)
- WARNING (yellow)
- ERROR (red)
- DEBUG (purple)

**Features:**
- Structured log entries with metadata
- Channel/user context
- Prevents logging loops
- Logs all events: messages, commands, reactions, errors

---

## Data Flow Patterns

### User Onboarding Flow

```
/join command
    ↓
CommandHandler.handleJoin()
    ↓
getUserByDiscordId() → Check if exists
    ↓
If new:
    createUser() → Notion Users DB
    ↓
    PersonalChannelManager.createPersonalChannel()
    ↓
    updateUser(personalChannelId)
    ↓
    Send welcome message with onboarding button
    ↓
If exists:
    Reactivate if paused
    Enroll in current batch if available
```

### Automatic Proof Detection Flow

```
User posts: "30min meditation"
    ↓
Bot.messageCreate event
    ↓
Check if accountability channel → YES
    ↓
ProofProcessor.processMessage()
    ↓
resolveWebhookUser() / getUserByDiscordId()
    ↓
getHabitsByUserId() + filterByCurrentBatch()
    ↓
MessageAnalyzer.analyzeContentWithHabitMatching()
    ↓
PerplexityClient.performAISemanticMatching()
    → AI matches to "Meditation" habit
    → Extracts unit: "30 minutes"
    ↓
createProof() → Notion Proofs DB
    ↓
React ✅ on message
    ↓
Send confirmation: "Meditation proof logged! (5/7 this week)"
```

### Weekly Evaluation Flow

```
Cron: Sunday 8:00 AM
    ↓
AIIncentiveManager.runWeeklyAIIncentiveAnalysis()
    ↓
Check if batch active → YES
    ↓
getUsersInBatch(currentBatch)
    ↓
For each active user:
    ↓
    getHabitsByUserId()
    ↓
    getProofsByUserId(currentWeek)
    ↓
    getProofsByUserId(lastWeek)
    ↓
    analyzeHabitsProgressEnhanced()
        ↓
        For each habit:
            - Calculate 66-day journey (day number, progress %)
            - Calculate trend (current vs last week)
            - Analyze weekdays (best/worst)
            - Calculate streaks (current, best, average)
            - Get AI tip from Perplexity
            - Generate trend graph (if ≥4 weeks data)
    ↓
    createAIIncentiveMessage()
        → Format Notion-style message
        → Attach PNG trend graphs
    ↓
    sendLongMessage() → User's personal channel
    ↓
    createWeek() → Notion Weeks DB
```

### Batch Activation Flow

```
Cron: Daily 6:00 AM
    ↓
DailyMessageScheduler.checkAndActivateBatch()
    ↓
shouldBatchStart() → Check current-batch.json
    ↓
If pre-phase batch should start:
    updateBatchStatus('active')
    ↓
    addBatchToAllActiveUsers(batchName)
    ↓
    BuddyRotationScheduler.assignBuddiesForBatch()
        ↓
        getUsersInBatch(batchName) where status='active'
        ↓
        Shuffle users randomly
        ↓
        Pair sequentially (user[0] with user[1], etc.)
        ↓
        For each pair:
            updateUserBuddy(user1, user2.nickname, todayDate)
            updateUserBuddy(user2, user1.nickname, todayDate)
        ↓
        Send buddy assignment messages
    ↓
    Send Day 1 announcement to accountability channel
```

---

## Design Patterns & Principles

### 1. Singleton Pattern
- **AgentRegistry:** Single instance managing all agents
- **AgentSystem:** Single orchestrator
- **ChallengeStateManager:** Single challenge state

### 2. Factory Pattern
- Command registration and handler mapping
- Agent creation in `initializeAgents()`

### 3. Observer Pattern
- Event-driven message processing
- Discord event handlers

### 4. Strategy Pattern
- Multiple proof sources (manual, automatic, webhook)
- Multiple AI models (Perplexity with failover)

### 5. Chain of Responsibility
- Message processing pipeline with priority
- Agent selection and routing

### 6. Template Method Pattern
- **BaseAgent** defines template
- Subclasses implement specifics

### 7. Adapter Pattern
- **CrewAIClient** adapts Python agents to TypeScript
- **NotionHabitTool** adapts Notion API to CrewAI

---

## Performance Considerations

### Optimization Strategies

**1. Caching:**
- Profile storage (24-hour file cache)
- Hash-based change detection
- Modal state (5-minute TTL)

**2. Query Optimization:**
- Batch filtering reduces dataset
- Indexed queries by Discord ID
- Date range filtering on proofs

**3. API Management:**
- Perplexity model failover (cheapest first)
- Context compression (≤2000 tokens)
- Batch processing where possible

**4. Resource Limits:**
- Docker memory: 256M-512M
- Docker CPU: 0.25-0.5 cores
- Log rotation: 3 files x 10MB

**5. Error Handling:**
- Graceful degradation (AI features)
- Fallback mechanisms
- Continue on individual failures

---

## Security Considerations

### 1. Docker Security
- Non-root user (`node`)
- Multi-stage builds
- Minimal attack surface

### 2. Environment Variables
- All secrets in `.env` (excluded from git)
- Validated at startup
- No hardcoded credentials

### 3. Discord Permissions
- Minimal required permissions
- Channel-specific access control
- Admin commands restricted to admin channel

### 4. Data Validation
- User input sanitization
- Discord ID verification
- Batch filtering prevents cross-contamination

---

## Deployment Architecture

### Docker Container

**Image:** `habit-discord-bot:optimized` (460MB)

**Base:** Node.js 18 Alpine Linux

**Structure:**
```
/app/
├── dist/ (1.1MB compiled JavaScript)
├── node_modules/ (97MB production dependencies)
├── logs/ (560KB persistent)
├── data/ (40KB persistent)
└── package.json
```

**Resource Configuration:**
- Memory: 256M (reserved) - 512M (limit)
- CPU: 0.25 cores (reserved) - 0.5 cores (limit)
- Restart: unless-stopped
- Health checks: Every 30s

**Volumes:**
- `./logs:/app/logs` - Persistent logs
- `./data:/app/data` - Profiles, challenge state

**Deployment Scripts:**
- `deploy.sh` - Build and deploy
- `update-and-deploy.sh` - Git pull + deploy
- `docker-commands.sh` - Container management

---

## Technology Stack Summary

### Core Technologies
- **TypeScript** (strict mode)
- **Node.js** 18 Alpine
- **Discord.js** v14
- **Notion API** (@notionhq/client)

### AI & ML
- **Perplexity AI** (Sonar model)
- **CrewAI** (Python multi-agent)
- **Canvas** (node-canvas for graphs)

### Scheduling & Automation
- **node-cron** (6 schedulers)
- **setInterval** (webhook polling)

### Testing
- **Jest** (unit tests)
- **ts-jest** (TypeScript support)

### Deployment
- **Docker** (containerization)
- **docker-compose** (orchestration)

### Python Stack
- **Flask** (API server)
- **CrewAI** (agent framework)
- **langchain-openai** (LLM integration)
- **notion-client** (Python SDK)

---

## File Structure Overview

```
/home/pi/Documents/habit_System/Habit_system_discord/
├── src/
│   ├── index.ts (Entry point - 95 lines)
│   ├── bot/ (13,022 lines total)
│   │   ├── bot.ts (Main orchestrator - 1,486 lines)
│   │   ├── commands.ts (User commands - 873 lines)
│   │   ├── admin-commands.ts (Admin commands - 198 lines)
│   │   ├── habit-flow.ts (Modal flow - 789 lines)
│   │   ├── proof-processor.ts (Proof handling - 456 lines)
│   │   ├── message-analyzer.ts (AI classification - 654 lines)
│   │   ├── personal-assistant.ts (AI assistant - 532 lines)
│   │   ├── tools-assistant.ts (Tool matching - 289 lines)
│   │   ├── daily-message-scheduler.ts (Daily cron - 234 lines)
│   │   ├── ai-incentive-manager.ts (Weekly evals - 678 lines)
│   │   ├── accountability-scheduler.ts (Financial - 156 lines)
│   │   ├── challenge-scheduler.ts (Challenges - 567 lines)
│   │   ├── midweek-scheduler.ts (CrewAI trigger - 123 lines)
│   │   ├── webhook-poller.ts (Polling - 198 lines)
│   │   ├── buddy-rotation-scheduler.ts (Buddy system - 234 lines)
│   │   ├── channel-handlers.ts (Routing - 187 lines)
│   │   ├── discord-logger.ts (Logging - 234 lines)
│   │   └── personal-channel-manager.ts (Channels - 156 lines)
│   ├── agents/ (11 files)
│   │   ├── orchestrator/orchestrator.ts (795 lines)
│   │   ├── mentor/mentor_agent.ts (1,456 lines)
│   │   ├── identity/identity_agent.ts (322 lines)
│   │   ├── accountability/accountability_agent.ts (359 lines)
│   │   ├── accountability/accountability_money_agent.ts (535 lines)
│   │   ├── group/group_agent.ts (313 lines)
│   │   ├── learning/learning_agent.ts (324 lines)
│   │   ├── base/agent.ts (267 lines)
│   │   ├── base/types.ts (230+ lines)
│   │   └── crewai-client.ts (147 lines)
│   ├── notion/
│   │   └── client.ts (Notion integration - 2,261 lines)
│   ├── ai/
│   │   └── perplexity-client.ts (AI client - 178 lines)
│   ├── toolbox/
│   │   ├── tools.ts (Tool definitions - 456 lines)
│   │   └── tools-enhanced.ts (Enhanced tools - 234 lines)
│   ├── types/
│   │   └── index.ts (Type definitions - 345 lines)
│   └── utils/
│       ├── batch-manager.ts (Batch logic - 156 lines)
│       └── trend-graph-generator.ts (Graphs - 234 lines)
├── python-agents/
│   ├── api.py (Flask API - 176 lines)
│   ├── midweek_agent.py (CrewAI agent - 155 lines)
│   └── tools/notion_tool.py (Notion integration - 325 lines)
├── tests/ (Test files)
├── data/ (Persistent data - 40KB)
│   ├── current-batch.json
│   └── profiles/
├── logs/ (Container logs - 560KB)
├── Dockerfile (Multi-stage build)
├── docker-compose.yml (Orchestration)
├── deploy.sh
├── update-and-deploy.sh
├── docker-commands.sh
└── package.json (Dependencies & scripts)
```

---

## Conclusion

The Discord Habit System is a sophisticated, production-ready platform that combines:

- **Comprehensive Architecture:** 53 TypeScript files with clear separation of concerns
- **Multi-Agent AI:** 5 specialized agents + Python CrewAI integration
- **Database Integration:** 10 Notion databases with 2,261 lines of client code
- **Automation:** 6 schedulers managing daily, weekly, and challenge workflows
- **User Experience:** 19 slash commands, multi-modal flows, automatic proof detection
- **Deployment:** Optimized Docker container (460MB) with persistent storage
- **Performance:** Resource-limited, health-checked, log-rotated
- **Security:** Non-root user, environment variables, input validation

**Key Metrics:**
- **Codebase:** 20,000+ lines of TypeScript
- **Databases:** 10 Notion databases
- **Commands:** 19 slash commands
- **Agents:** 5 TypeScript + 1 Python CrewAI
- **Schedulers:** 6 automated cron jobs
- **Docker Image:** 460MB optimized
- **Active Users:** 8 registered, 6 with fresh profiles

**Production Status:** Healthy, running 10+ hours, all systems operational.
