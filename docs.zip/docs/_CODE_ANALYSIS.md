# Code Analysis: Active vs Unused Files

**Generated:** 2025-12-29
**Docker Container:** habit-discord-bot (running, healthy)

## Summary

- **Total .md files found:** 200+ (including venv dependencies)
- **Root test files:** 41 test/debug scripts
- **Active TypeScript files (src/):** 51 files
- **Unused/Old files identified:** Multiple test scripts, old documentation

---

## ✅ ACTIVE CODE (Currently Running in Docker)

### Core Application (src/)

**Entry Point:**
- `src/index.ts` ✅ ACTIVE

**Bot Layer (src/bot/):**
- `bot.ts` ✅ ACTIVE - Main orchestrator (1,486 lines)
- `commands.ts` ✅ ACTIVE - User commands
- `admin-commands.ts` ✅ ACTIVE - Admin commands
- `habit-flow.ts` ✅ ACTIVE - 4-step habit creation
- `proof-processor.ts` ✅ ACTIVE - Proof handling
- `message-analyzer.ts` ✅ ACTIVE - AI classification
- `personal-assistant.ts` ✅ ACTIVE - AI assistant
- `tools-assistant.ts` ✅ ACTIVE - Tool matching
- `personal-channel-manager.ts` ✅ ACTIVE - Channel creation
- `channel-handlers.ts` ✅ ACTIVE - Message routing
- `discord-logger.ts` ✅ ACTIVE - Logging system

**Schedulers (src/bot/):**
- `daily-message-scheduler.ts` ✅ ACTIVE - 6 AM daily cron
- `ai-incentive-manager.ts` ✅ ACTIVE - Sunday 8 AM evaluations
- `accountability-scheduler.ts` ✅ ACTIVE - Sunday 8 PM financial
- `challenge-scheduler.ts` ✅ ACTIVE - Weekly challenges
- `midweek-scheduler.ts` ✅ ACTIVE - Wednesday 8 PM CrewAI
- `webhook-poller.ts` ✅ ACTIVE - 10-second polling
- `weekly-agent-scheduler.ts` ✅ ACTIVE - Marc's personal analysis
- `all-users-weekly-scheduler.ts` ✅ ACTIVE - Batch-wide analysis
- `buddy-rotation-scheduler.ts` ✅ ACTIVE - Buddy assignment

**Challenge System (src/bot/):**
- `challenge-manager.ts` ✅ ACTIVE - 20 challenges
- `challenge-proof-processor.ts` ✅ ACTIVE - Challenge proofs
- `challenge-state.ts` ✅ ACTIVE - State management
- `accountability-report-formatter.ts` ✅ ACTIVE - Report formatting

**Agent System (src/agents/):**
- `orchestrator/orchestrator.ts` ✅ ACTIVE
- `mentor/mentor_agent.ts` ✅ ACTIVE
- `identity/identity_agent.ts` ✅ ACTIVE (disabled in production)
- `accountability/accountability_agent.ts` ✅ ACTIVE
- `accountability/accountability_money_agent.ts` ✅ ACTIVE
- `group/group_agent.ts` ✅ ACTIVE
- `learning/learning_agent.ts` ✅ ACTIVE
- `base/agent.ts` ✅ ACTIVE - Base class
- `base/types.ts` ✅ ACTIVE - Type system (230+ types)
- `crewai-client.ts` ✅ ACTIVE - Python bridge
- `index.ts` ✅ ACTIVE

**AI Features (src/ai/):**
- `perplexity-client.ts` ✅ ACTIVE
- `query-classifier.ts` ✅ ACTIVE
- `profile-storage.ts` ✅ ACTIVE
- `profile-generator.ts` ✅ ACTIVE
- `dynamic-context-builder.ts` ✅ ACTIVE
- `context-compressor.ts` ✅ ACTIVE
- `perplexity-tool-matcher.ts` ✅ ACTIVE

**Toolbox (src/toolbox/):**
- `index.ts` ✅ ACTIVE
- `tools.ts` ✅ ACTIVE
- `tools-enhanced.ts` ✅ ACTIVE - 40+ tools

**Data Layer (src/notion/):**
- `client.ts` ✅ ACTIVE - 2,261 lines, all DB operations

**Types (src/types/):**
- `index.ts` ✅ ACTIVE - All TypeScript interfaces

**Utilities (src/utils/):**
- `batch-manager.ts` ✅ ACTIVE - Batch lifecycle
- `trend-graph-generator.ts` ✅ ACTIVE - PNG graphs
- `cycle-calculator.ts` ✅ ACTIVE

**Testing Framework (src/test/):**
- `test-framework.ts` ✅ ACTIVE
- `discord-test-runner.ts` ✅ ACTIVE

---

## ❌ UNUSED/OLD CODE (Not in Docker Container)

### Root Test Files (41 files - ARCHIVE CANDIDATES)

**Agent Testing:**
- `test-agent-system.js` ❌ OLD - Manual agent testing
- `test_agents.js` ❌ OLD
- `test_agents_simple.js` ❌ OLD
- `test_agents_mock.js` ❌ OLD
- `test-ai-analysis.js` ❌ OLD
- `test-ai-fixed.js` ❌ OLD
- `test-ai-incentive-system.js` ❌ OLD

**Marc-Specific Tests:**
- `test-marc-buddy-discord.ts` ❌ OLD
- `test-marc-full-analysis.ts` ❌ OLD
- `test-marc-discord-simple.ts` ❌ OLD

**Buddy System Tests:**
- `test-buddy-summary.ts` ❌ OLD
- `test-buddy-message.ts` ❌ OLD
- `test-buddy-message.js` ❌ OLD
- `test-buddy-system.ts` ❌ OLD
- `test-buddy-system-complete.ts` ❌ OLD
- `test-buddy-nickname-matching.ts` ❌ OLD

**Challenge System Tests:**
- `test-challenge-system.js` ❌ OLD
- `test-challenge-flow.ts` ❌ OLD
- `test-poll-reactions.ts` ❌ OLD

**Feature Tests:**
- `test-join-command.js` ❌ OLD
- `test-automatic-proofing.js` ❌ OLD
- `test-proof-matching.js` ❌ OLD
- `test-minimal-dose-logic.js` ❌ OLD
- `test-learning.js` ❌ OLD
- `test-learning-simple.js` ❌ OLD
- `test-hurdles.js` ❌ OLD
- `test-profile-edit.ts` ❌ OLD
- `test-personality-db-save.ts` ❌ OLD

**Weekly Agents Tests:**
- `test-weekly-agents.ts` ❌ OLD

**Bot Tests:**
- `test-bot-functionality.js` ❌ OLD
- `test-bot-status.js` ❌ OLD
- `test-messages.js` ❌ OLD

**Debug Scripts:**
- `debug-bot.js` ❌ OLD
- `debug-bot-enhanced.js` ❌ OLD

**Infrastructure Tests:**
- `test-connections.js` ❌ OLD
- `test-logging-system.js` ❌ OLD
- `test-docker-setup.js` ❌ OLD

**Database Tests:**
- `check-notion-databases.js` ❌ OLD
- `check-notion-structure.js` ❌ OLD
- `check-personality-db-schema.ts` ❌ OLD

**Utility Scripts:**
- `send-startup-message.js` ❌ OLD - One-time script
- `get-channel-id.js` ❌ OLD - Utility script
- `demo-ai-tool-matching.ts` ❌ OLD - Demo script

**Config:**
- `ecosystem.config.js` ⚠️ KEEP - PM2 config (alternative runtime)

---

## 📄 DOCUMENTATION FILES

### Project Root Documentation (KEEP - Move to _DOCS_CONSOLIDATED)

**Architecture & Implementation:**
- `CLAUDE.md` ✅ KEEP - Project instructions for Claude Code
- `README.md` ✅ KEEP - Main readme
- `Agents.md` ✅ KEEP - Agent system overview
- `AGENTS_SYSTEM_ARCHITECTURE.md` ✅ KEEP
- `AGENTS_BATCH_ANALYSIS.md` ✅ KEEP

**Batch System:**
- `BATCH_CYCLE_IMPLEMENTATION_PLAN.md` ✅ KEEP
- `BATCH_IMPLEMENTATION_COMPLETE.md` ✅ KEEP
- `BATCH_SETUP_GUIDE.md` ✅ KEEP
- `BATCH_SYSTEM_SIMPLIFIED.md` ✅ KEEP
- `BATCH_USER_GUIDE.md` ✅ KEEP

**Agent Documentation:**
- `ACCOUNTABILITY_MONEY_AGENT_IMPLEMENTATION.md` ✅ KEEP
- `AGENT_DOCUMENTATION_SUMMARY.md` ✅ KEEP

**Database Documentation:**
- `DATABASE_DOCUMENTATION_SUMMARY.md` ✅ KEEP
- `DATABASE_SHARING_FIX.md` ✅ KEEP
- `DATABASE_SHARING_GUIDE.md` ✅ KEEP
- `NOTION_DATABASES_COMPLETE_REFERENCE.md` ✅ KEEP
- `NOTION_DB_REQUIREMENTS.md` ✅ KEEP
- `CREATE_PERSONALITY_DATABASE_GUIDE.md` ✅ KEEP

**Challenge System:**
- `CHALLENGE_NOTION_SCHEMA.md` ✅ KEEP
- `CHALLENGE_SETUP.md` ✅ KEEP

**AI Features:**
- `AI_SEMANTIC_MATCHING_ENHANCEMENT.md` ✅ KEEP
- `AI_TOOL_MATCHING_IMPLEMENTATION.md` ✅ KEEP

**Bug Fixes & Implementations:**
- `AUTOMATIC_PROOFING_FIX_SUMMARY.md` ✅ KEEP
- `LOGGING_DASHBOARD.md` ✅ KEEP

**Commands:**
- `CURRENT_SLASH_COMMANDS.md` ✅ KEEP

### docs/ Folder (ALREADY ORGANIZED)

**Architecture:**
- `docs/ARCHITECTURE.md` ✅ NEW - Complete system architecture (41KB)
- `docs/USER_JOURNEY.md` ✅ NEW - All user flows
- `docs/01_SYSTEM_ARCHITECTURE.md` ✅ KEEP
- `docs/10_IMPLEMENTATION_SUMMARY.md` ✅ KEEP

**Agent Specs:**
- `docs/02_MENTOR_AGENT_SPEC.md` ✅ KEEP
- `docs/03_IDENTITY_AGENT_SPEC.md` ✅ KEEP
- `docs/04_ACCOUNTABILITY_AGENT_SPEC.md` ✅ KEEP
- `docs/05_GROUP_AGENT_SPEC.md` ✅ KEEP
- `docs/06_LEARNING_HURDLES_AGENT_SPEC.md` ✅ KEEP

**Database:**
- `docs/07_NOTION_DATABASE_SCHEMAS.md` ✅ KEEP
- `docs/notion_database_schemas.md` ✅ KEEP
- `docs/database_ids.md` ✅ KEEP
- `docs/hurdles_database_schema.md` ✅ KEEP
- `docs/data_model.md` ✅ KEEP

**Configuration:**
- `docs/channel_configuration.md` ✅ KEEP
- `docs/discord_channel_structure.md` ✅ KEEP
- `docs/discord_bot_spec.md` ✅ KEEP

**Setup:**
- `docs/notion_setup_visual_guide.md` ✅ KEEP
- `docs/notion_integration.md` ✅ KEEP

**Other:**
- `docs/08_NEO4J_GRAPH_STRUCTURE.md` ⚠️ CHECK - Neo4j not used?
- `docs/operations.md` ✅ KEEP
- `docs/product_vision.md` ✅ KEEP
- `docs/metrics_analytics.md` ✅ KEEP

### Python Agents Documentation

**python-agents/:**
- `python-agents/README.md` ✅ KEEP
- `python-agents/QUICKSTART.md` ✅ KEEP
- `python-agents/INTEGRATION.md` ✅ KEEP

**money_agent/ (OLD):**
- `money_agent/agent.md` ❌ OLD - Superseded by accountability_money_agent.ts
- `money_agent/README.md` ❌ OLD

**mentor_agent/ (OLD?):**
- Check if still used or superseded by TypeScript version

### .agent-os/ & .cursor/ Folders (DEV TOOLING - KEEP)

**.agent-os/:** ✅ KEEP - Agent OS configuration
**.cursor/:** ✅ KEEP - Cursor IDE rules
**.claude/:** ✅ KEEP - Claude Code configuration

### Challenges Folder

**challenges/:**
- `challenges/weekly-challenges.md` ✅ KEEP - Challenge definitions

### User Profile Data

**data/profiles/:**
- All .md files ✅ KEEP - Auto-generated user profiles

---

## 🗂️ FOLDERS TO ARCHIVE

### money_agent/ - OLD Python Money Agent
**Status:** Replaced by `src/agents/accountability/accountability_money_agent.ts`
**Action:** Archive entire folder

### mentor_agent/ - OLD Python Mentor Agent
**Status:** Check if still used. TypeScript version exists at `src/agents/mentor/mentor_agent.ts`
**Action:** Archive if unused

### mock_data/ - Mock Data for Testing
**Status:** Testing data, not used in production
**Action:** Archive entire folder

---

## 📋 RECOMMENDED ACTIONS

### 1. Archive Old Test Files
Move all 41 test files from root to `_ARCHIVE_OLD_CODE/tests/`:
```bash
mv test-*.js test-*.ts _ARCHIVE_OLD_CODE/tests/
mv debug-*.js _ARCHIVE_OLD_CODE/tests/
mv check-*.js check-*.ts _ARCHIVE_OLD_CODE/tests/
mv demo-*.ts _ARCHIVE_OLD_CODE/tests/
mv send-startup-message.js _ARCHIVE_OLD_CODE/tests/
mv get-channel-id.js _ARCHIVE_OLD_CODE/tests/
```

### 2. Archive Old Python Agents
```bash
mv money_agent/ _ARCHIVE_OLD_CODE/
# Check mentor_agent first
```

### 3. Archive Mock Data
```bash
mv mock_data/ _ARCHIVE_OLD_CODE/
```

### 4. Consolidate Documentation
Move all root .md files to `_DOCS_CONSOLIDATED/`:
```bash
mv *.md _DOCS_CONSOLIDATED/
# Keep README.md and CLAUDE.md in root
cp _DOCS_CONSOLIDATED/README.md ./
cp _DOCS_CONSOLIDATED/CLAUDE.md ./
```

### 5. Create Archive Index
Create `_ARCHIVE_OLD_CODE/README.md` documenting what was archived and when.

---

## ⚠️ IMPORTANT NOTES

**DO NOT ARCHIVE:**
- `src/` folder - All active code
- `node_modules/` - Dependencies
- `dist/` - Compiled output (ignored by git anyway)
- `data/` - Persistent data (profiles, batch state)
- `logs/` - Application logs
- `.env` - Environment variables
- `package.json`, `package-lock.json` - Dependencies
- `tsconfig.json` - TypeScript config
- `Dockerfile`, `docker-compose.yml` - Deployment
- `ecosystem.config.js` - PM2 config (alternative runtime)
- `deploy.sh`, `update-and-deploy.sh`, `docker-commands.sh` - Deployment scripts
- `.dockerignore`, `.gitignore` - Config files
- `docs/` - Already organized documentation
- `.agent-os/`, `.cursor/`, `.claude/` - Dev tooling config
- `python-agents/` - Active Python CrewAI agent

**WHAT GETS DEPLOYED TO DOCKER:**
- Only `src/` compiled to `dist/`
- `node_modules/` (production only)
- `package.json`
- `data/` and `logs/` via volumes

**NOT DEPLOYED (per .dockerignore):**
- All .md files except README.md
- All test files
- All .sh scripts except docker-start.sh
- Mock data
- Python virtual environments

---

## 📊 STATISTICS

**Active Code:**
- TypeScript files: 51
- Lines of code: 20,000+
- Agents: 7 (5 TypeScript + 1 Python + 1 orchestrator)

**Unused Code:**
- Test/debug scripts: 41
- Old documentation: TBD after consolidation

**Documentation:**
- Root .md files: ~40
- docs/ folder: ~20
- Total .md files: 200+ (including venv dependencies - ignore those)

**Docker Container:**
- Image size: 460MB optimized
- Compiled code: 1.1MB
- Dependencies: 97MB
- Status: Healthy, running 10+ hours
